import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// High limits for handling sequences and base64 images/PDFs
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Lazy initialisation of GoogleGenAI or direct on-demand checking
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY environment variable is not configured. Please add it in Settings > Secrets.");
  }
  return new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

const SYSTEM_PROMPT = `You are an expert microbiologist and bioinformatician specializing in antimicrobial resistance (AMR). 
Provide accurate, evidence-based, concise scientific analysis. 
Where applicable, cite key AMR reference databases (such as CARD - Comprehensive Antibiotic Resistance Database, ResFinder, NCBI AMRFinderPlus, and PATRIC). 
If a sequence contains mutations or features that do not match known high-confidence AMR determinants, flag this uncertainty clearly. 
Keep explanations highly professional, technical yet accessible to researchers, using appropriate nomenclature (e.g., specific protein substitutions, resistance mechanisms like efflux pumps, target modification, or enzymatic inactivation).`;

// 1. Analyze file endpoint
app.post("/api/analyze", async (req, res) => {
  try {
    const { fileType, fileName, fileContent, additionalContext } = req.body;
    const ai = getGeminiClient();

    let prompt = "";
    let contents: any[] = [];

    if (fileType === "fasta") {
      prompt = `Analyze the following FASTA sequence. 
1. Identify potential Open Reading Frames (ORFs) or gene regions.
2. Cross-reference with standard AMR databases to find homology to known resistance genes (e.g., beta-lactamases like blaCTX-M, aminoglycoside modulators, efflux pumps).
3. Provide a clear resistance profiling, detailing the gene names, resistance mechanisms, suspected antibiotic classes affected, and a confidence estimation (High/Medium/Low).
4. Outline 3 suggested follow-up experiments or database lookups.

FASTA Content:
${fileContent}

Additional Context: ${additionalContext || "None provided"}`;
      contents.push({ text: prompt });
    } else if (fileType === "vcf") {
      prompt = `Analyze the following genomic variants (VCF records). 
1. Identify high-impact mutations (missense, frameshift, nonsense, promoter mutations) in key bacterial resistance determinants (e.g., gyrA/parC in fluoroquinolone resistance, rpoB in rifampin resistance, pbp2a in methicillin resistance). 
2. Classify each key mutation's threat/suspected severity (Pathogenic/AMR-Conferring, Benign, or Unknown Significance) and map it on a 0-100 severity score.
3. Detail the exact codon changes (e.g., Ser83Leu) and describe the molecular structural impact (e.g., disruption of drug-binding pocket).

VCF Content:
${fileContent}`;
      contents.push({ text: prompt });
    } else if (fileType === "paper") {
      prompt = `Analyze the research paper text provided below.
1. Provide a concise scientific summary (Abstract, Key Findings, Methodology).
2. Explicitly list all AMR genes, mutations, bacterial species, and antibiotic susceptibility profiles discussed.
3. Highlight novel resistance mechanisms proposed.
4. Suggest follow-up experimental workflows or validation studies.

Paper Content excerpt:
${fileContent}`;
      contents.push({ text: prompt });
    } else if (fileType === "ast") {
      prompt = `Interpret this Susceptibility Profile/Antibiotic Susceptibility Testing (AST) report. 
1. Map the testing values to standard resistance classifications (Susceptible, Intermediate, Resistant).
2. Generate an elegant, highly structured scientific summary explaining the resistance phenotype (e.g., MDR, XDR, Pan-Drug Resistant) and identifying potential enzymatic drivers (such as ESBL, Carbapenemase, or AmpC expression).
3. Draft a clinical surveillance suggestion card.

AST Report Details:
${fileContent}`;
      contents.push({ text: prompt });
    } else if (fileType === "genelist") {
      prompt = `Given the list of bacterial genes provided, analyze each gene's involvement in resistance mechanisms:
1. Provide a detailed description of the resistance superfamily/mechanism for each (e.g., Major Facilitator Superfamily efflux pump, ribosomal protection, enzymatic target shielding).
2. Identify which classes of antibiotics are compromised.
3. Highlight any synergistic combinations of these list members (e.g., beta-lactamase + outer membrane porin loss).

Gene List:
${fileContent}`;
      contents.push({ text: prompt });
    } else if (fileType === "protein") {
      // Handles case where user uploads a protein structure image (base64)
      prompt = `Analyze this molecular structure/folding plot of an AMR protein. 
1. Identify structural elements (helices, sheets, loop regions) or active site pockets if discernible.
2. Explain how common mutations in these domains might lead to steric hindrance or altered electrostatic charge, thereby preventing antibiotic binding (e.g., penicillin-binding protein alterations, altered ribosomal target loops).
3. Outline how this protein functions structurally (e.g., dimerisation, catalytic domain arrangement).`;
      
      if (fileContent && fileContent.startsWith("data:image")) {
        const commaIdx = fileContent.indexOf(",");
        const base64Data = fileContent.substring(commaIdx + 1);
        const mimeType = fileContent.substring(5, commaIdx).split(";")[0];
        
        contents.push({
          inlineData: {
            mimeType: mimeType,
            data: base64Data
          }
        });
      }
      contents.push({ text: prompt });
    } else {
      prompt = `Analyze the following AMR data:
${fileContent}`;
      contents.push({ text: prompt });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.1, // more deterministic for scientific accuracy
      }
    });

    res.json({
      success: true,
      analysis: response.text,
      rawOutput: response,
    });
  } catch (error: any) {
    console.error("Analysis Error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "An error occurred during Gemini resistance analysis.",
    });
  }
});

// 2. Chat endpoint
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, activeFileContext } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ success: false, error: "Messages array is required." });
    }

    const ai = getGeminiClient();

    // Prepare message contents
    const contents: any[] = [];
    
    // Inject active file context as prime grounding if available
    let contextHeader = "";
    if (activeFileContext && activeFileContext.name) {
      contextHeader = `[ACTIVE SCIENTIFIC CONTEXT ACTIVE]
The researcher has loaded a file named "${activeFileContext.name}" inside their workspace. 
File Type: ${activeFileContext.type.toUpperCase()}
Content Summary/Details:
${activeFileContext.metadata || activeFileContext.content}
---------------------------------------------------\n\n`;
    }

    // Convert chat history messages into standard Gemini prompt parts
    for (let i = 0; i < messages.length; i++) {
      const msg = messages[i];
      const partText = i === messages.length - 1 ? (contextHeader + msg.content) : msg.content;
      contents.push({
        role: msg.role === "user" ? "user" : "model",
        parts: [{ text: partText }]
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: contents,
      config: {
        systemInstruction: SYSTEM_PROMPT + "\nAnswer user questions thoroughly and with clean formatting. Provide concise, bold bullet points for lists, use markdown tables for data, and format gene names and gene sequences in markdown code blocks.",
        temperature: 0.2,
      }
    });

    res.json({
      success: true,
      message: response.text,
    });
  } catch (error: any) {
    console.error("Chat Error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "An error occurred during scientific consultation.",
    });
  }
});

// 3. Report generation endpoint
app.post("/api/generate-report", async (req, res) => {
  try {
    const { files, reportType, additionalNotes } = req.body;
    const ai = getGeminiClient();

    const fileSummaries = files.map((f: any, idx: number) => {
      return `File ${idx + 1}: ${f.name} (${f.type.toUpperCase()})
Analysis output:
${f.analysisResult || "No raw analysis performed. Full Content: " + String(f.content).substring(0, 500)}`;
    }).join("\n\n---\n\n");

    const prompt = `Generate a publication-grade, professional scientific report based on the following bioinformatics data collected in the lab:

REPORT TYPE: ${reportType === "full" ? "Full Comprehensive Scientific Report" : reportType === "clinical" ? "Clinical Resistance surveillance Brief" : "Executive Summary"}
ADDITIONAL SCIENTIFIC NOTES: ${additionalNotes || "None"}

BIOINFORMATICS INPUT DATASETS:
${fileSummaries}

Please format the draft with beautiful Markdown sections suitable for academic / clinical submission:
1. Executive Abstract
2. Laboratory Methodology & Sequence Sourcing
3. Identified Resistance Determinants & Genomic Mutation Catalog (use markdown tables)
4. Genotype-Phenotype Susceptibility Correlation Analysis
5. Therapeutic Implications & Suggested Follow-up Diagnostic Reservoirs (citation of CARD, ResFinder, NCBI AMRFinderPlus)
6. Concluding Recommendation for Resistance Surveillance

Ensure each section has substantive content. Do not output placeholders. Maintain peak academic writing standards.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [{ text: prompt }],
      config: {
        systemInstruction: SYSTEM_PROMPT,
        temperature: 0.2,
      }
    });

    res.json({
      success: true,
      report: response.text,
    });
  } catch (error: any) {
    console.error("Report Generation Error:", error);
    res.status(500).json({
      success: false,
      error: error.message || "An error occurred during report preparation.",
    });
  }
});

// Start server
async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // SPA fallback
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AMR Insight AI full-stack backend running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
