import React, { useState, useRef, useEffect } from "react";
import { Send, FileCheck, X, Sparkles, Terminal, Copy, Check, MessageSquare, AlertCircle } from "lucide-react";
import { ChatMessage, ResearchFile } from "../types";

interface ChatWorkspaceProps {
  files: ResearchFile[];
  chatMessages: ChatMessage[];
  onSendMessage: (text: string, activeContextId?: string) => void;
  isSending: boolean;
}

const CHAT_SUGGESTIONS = [
  "Does blaCTX-M-15 confer resistance to Meropenem?",
  "What is the structural role of mgrB loss in colistin escape?",
  "Analyze synergistic therapeutic cocktails for oxacillinase isolates.",
  "Which CARD database term corresponds to NDM-5?"
];

export default function ChatWorkspace({ files, chatMessages, onSendMessage, isSending }: ChatWorkspaceProps) {
  const [inputText, setInputText] = useState("");
  const [selectedContextId, setSelectedContextId] = useState<string>(files[0]?.id || "");
  const [copiedMessageId, setCopiedMessageId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to lowest message
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages, isSending]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isSending) return;
    onSendMessage(inputText, selectedContextId);
    setInputText("");
  };

  const handleSuggestionClick = (suggestion: string) => {
    if (isSending) return;
    onSendMessage(suggestion, selectedContextId);
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMessageId(id);
    setTimeout(() => setCopiedMessageId(null), 1500);
  };

  const activeContextFile = files.find(f => f.id === selectedContextId);

  return (
    <div id="chat-workspace-wrapper" className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-160px)]">
      
      {/* Messages Thread panel (8 Columns) */}
      <div className="lg:col-span-8 flex flex-col justify-between rounded-2xl bg-[#131826]/40 border border-white/5 overflow-hidden h-full">
        
        {/* Thread Header Context Selector */}
        <div className="p-4 bg-slate-900/60 border-b border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-400" />
            <span className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">Gemini Grounded Consultation</span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono text-slate-500 font-bold uppercase">Active Reference:</span>
            {activeContextFile ? (
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-indigo-500/10 rounded-lg border border-indigo-500/20 text-xs font-semibold text-indigo-300 min-w-0 max-w-[200px]">
                <span className="truncate">{activeContextFile.name}</span>
                <button 
                  onClick={() => setSelectedContextId("")}
                  className="hover:text-red-400 p-0.5"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ) : (
              <select
                value={selectedContextId}
                onChange={(e) => setSelectedContextId(e.target.value)}
                className="px-2 py-1 bg-slate-900 border border-slate-800 rounded-lg text-[11px] font-semibold text-slate-400 outline-none"
              >
                <option value="">No Grounding File (Global)</option>
                {files.map(f => (
                  <option key={f.id} value={f.id}>{f.name}</option>
                ))}
              </select>
            )}
          </div>
        </div>

        {/* Message bubbles body */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6">
          {chatMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <MessageSquare className="w-10 h-10 text-slate-700" />
              <div>
                <h4 className="text-sm font-semibold text-slate-300">Consult with the AMR AI Assistant</h4>
                <p className="text-xs text-slate-500 max-w-sm mt-1">
                  Ask questions about drug targets, mechanism summaries, or ask to compare specific gene records.
                </p>
              </div>
            </div>
          ) : (
            chatMessages.map((msg) => (
              <div 
                key={msg.id}
                className={`flex gap-4 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {/* AI Icon Avatar */}
                {msg.role === "assistant" && (
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 via-cyan-500 to-emerald-400 flex items-center justify-center shadow-lg shadow-indigo-500/10 shrink-0 select-none">
                    <Sparkles className="w-4 h-4 text-slate-900" />
                  </div>
                )}

                {/* Bubble */}
                <div 
                  className={`max-w-[85%] p-4 rounded-2xl border text-xs leading-relaxed space-y-3 relative ${
                    msg.role === "user" 
                      ? "bg-indigo-600/10 border-indigo-500/20 text-indigo-100 rounded-tr-none" 
                      : "bg-[#131826]/70 border-white/5 text-slate-300 rounded-tl-none"
                  }`}
                >
                  <div className="whitespace-pre-wrap font-normal leading-relaxed">
                    {msg.content}
                  </div>

                  {/* Footnotes / citations representation */}
                  {msg.role === "assistant" && activeContextFile && (
                    <div className="pt-2.5 border-t border-white/5 flex items-center justify-between text-[9px] font-mono text-slate-500">
                      <span className="flex items-center gap-1.5 font-semibold text-slate-400">
                        <FileCheck className="w-3.5 h-3.5 text-emerald-400" />
                        Grounded: {activeContextFile.name}
                      </span>
                      
                      <button
                        onClick={() => copyToClipboard(msg.content, msg.id)}
                        className="hover:text-white flex items-center gap-1 p-1 hover:bg-white/5 rounded transition-colors"
                      >
                        {copiedMessageId === msg.id ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            Copied
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            Copy Output
                          </>
                        )}
                      </button>
                    </div>
                  )}

                  <span className="absolute bottom-1 right-2 text-[8px] font-mono text-slate-600 select-none">{msg.timestamp}</span>
                </div>
              </div>
            ))
          )}

          {/* AI is thinking/shimmer loop */}
          {isSending && (
            <div className="flex gap-4 justify-start">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center shadow-lg shrink-0 animate-pulse">
                <Sparkles className="w-4 h-4 text-slate-900" />
              </div>
              <div className="p-4 rounded-2xl bg-[#131826]/40 border border-white/5 rounded-tl-none text-xs text-slate-500 flex items-center gap-3">
                <div className="flex gap-1">
                  <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce"></span>
                  <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                </div>
                <span className="font-mono text-[10px] text-indigo-300">Gemini checking CARD databases...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input box form */}
        <form onSubmit={handleSubmit} className="p-4 bg-slate-900/60 border-t border-white/5 flex gap-3">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={activeContextFile ? `Ask regarding ${activeContextFile.name}...` : "Ask a general AMR question..."}
            className="flex-1 px-4 py-3 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-100 outline-none focus:border-indigo-500/50"
            disabled={isSending}
          />
          <button
            type="submit"
            disabled={isSending || !inputText.trim()}
            className="px-4 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-xl flex items-center justify-center transition-all cursor-pointer"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>

      {/* Suggested chips and grounding details side (4 Columns) */}
      <div className="lg:col-span-4 space-y-6 flex flex-col justify-between h-full">
        
        {/* Suggested chips panel */}
        <div className="p-5 rounded-2xl bg-[#131826]/60 border border-white/5 space-y-4">
          <div>
            <h4 className="text-xs font-bold text-white font-mono uppercase tracking-wider">Suggested Consultations</h4>
            <p className="text-[10px] text-slate-500">Quick-fire bioinformatics prompts mapped to uploaded vectors</p>
          </div>

          <div className="space-y-2">
            {CHAT_SUGGESTIONS.map((tpl, key) => (
              <button
                key={key}
                onClick={() => handleSuggestionClick(tpl)}
                disabled={isSending}
                className="w-full p-3 rounded-lg text-left text-xs bg-slate-950/60 border border-white/5 text-slate-300 hover:border-indigo-500/30 hover:bg-[#131826]/40 transition-all block disabled:opacity-45 cursor-pointer font-normal"
              >
                {tpl}
              </button>
            ))}
          </div>
        </div>

        {/* Grounding specifications card */}
        <div className="p-5 rounded-2xl bg-[#131826]/60 border border-white/5 space-y-4">
          <div className="flex items-center gap-2 text-indigo-400 font-mono text-[11px] font-bold uppercase tracking-wider">
            <Terminal className="w-4 h-4" />
            <span>AI Citation Rules</span>
          </div>
          <div className="text-[11px] text-slate-400 space-y-2.5 leading-relaxed font-sans">
            <p>
              1. **CARD Alignment**: Gemini prioritizes exact matching against CARD (Comprehensive Antibiotic Resistance Database) term standards.
            </p>
            <p>
              2. **Phenotype Check**: Susceptibility evaluations correspond directly to standard EUCAST and CLSI boundaries.
            </p>
            <p>
              3. **Surveillance Sourcing**: Highlights are retrieved from plasmid transfer markers.
            </p>
          </div>
        </div>

      </div>

    </div>
  );
}
