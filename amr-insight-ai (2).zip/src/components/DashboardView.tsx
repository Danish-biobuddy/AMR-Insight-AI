import React from "react";
import { FileText, Database, ShieldAlert, Sparkles, Plus, MessageSquare, BookOpen, Clock, CheckCircle2, AlertTriangle, ArrowRight } from "lucide-react";
import { ResearchFile, StatCardData, Tab } from "../types";

interface DashboardViewProps {
  files: ResearchFile[];
  onNavigate: (tab: Tab) => void;
  onSelectFile: (file: ResearchFile) => void;
}

export default function DashboardView({ files, onNavigate, onSelectFile }: DashboardViewProps) {
  // Compute basic aggregates based on current files
  const totalAnalyzed = files.filter(f => f.status === "analyzed").length;
  const totalFiles = files.length;
  const activeProjects = 3; // static sample
  const totalReportsGenerated = 5; // static sample

  const stats: StatCardData[] = [
    {
      title: "Biomarker Uploads",
      value: totalFiles,
      icon: "FileText",
      change: "+2 this cycle",
      trend: "up"
    },
    {
      title: "Detected Resistances",
      value: "14 High-Risk",
      icon: "ShieldAlert",
      change: "+4 critical threats",
      trend: "up"
    },
    {
      title: "Surveillance Dossiers",
      value: totalReportsGenerated,
      icon: "Database",
      change: "Drafted via AI",
      trend: "neutral"
    },
    {
      title: "Active Isolates",
      value: activeProjects,
      icon: "Sparkles",
      change: "Stable in context",
      trend: "neutral"
    }
  ];

  // Activities to display in timeline
  const activities = [
    {
      id: "a1",
      title: "Genomic Sequence Parsed",
      text: "blaCTX-M-15 detected with 100% homology in E_coli_isolate_blaCTX-M-15_assembly.fasta.",
      time: "2 hours ago",
      type: "success", // green accent
    },
    {
      id: "a2",
      title: "Critical Mutation Warning",
      text: "mgrB Nonsense mutation [Gln30*] flagged in Klebsiella pneumoniae. Mediates colistin failure.",
      time: "1 day ago",
      type: "danger", // red accent
    },
    {
      id: "a3",
      title: "AST Phenotype Intersected",
      text: "Acinetobacter baumannii report linked: exhibits Pan-Drug resistant traits.",
      time: "2 days ago",
      type: "warning", // yellow accent
    },
    {
      id: "a4",
      title: "Literature Summary Extracted",
      text: "Abstract summaries retrieved from Plasmid review. Plasmids tagged on IncX3 groups.",
      time: "4 days ago",
      type: "info", // purple accent
    }
  ];

  return (
    <div id="dashboard-wrapper" className="space-y-8">
      {/* Welcome Banner */}
      <div id="welcome-banner" className="relative p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-[#161d30] to-indigo-950/40 border border-indigo-500/10 overflow-hidden">
        <div className="absolute top-0 right-0 w-[300px] h-full bg-gradient-to-l from-indigo-500/10 to-transparent blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <h1 className="text-2xl font-display font-medium text-white tracking-tight flex items-center gap-2.5">
              Welcome to AMR Insight Workspace
              <span className="text-xl">🔬</span>
            </h1>
            <p className="text-xs text-slate-400 max-w-xl">
              Upload your sequence data, clinical AST records, or variant lists. Use Gemini AI to cross-reference resistance markers and generate clinical-grade analysis summaries.
            </p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => onNavigate(Tab.Upload)}
              className="px-4 py-2.5 bg-gradient-to-r from-indigo-500 to-cyan-500 hover:opacity-95 text-slate-950 font-semibold rounded-xl text-xs flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-indigo-500/10"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              New Sequence Upload
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div id="dashboard-stats" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((st, i) => (
          <div key={i} className="p-6 rounded-2xl bg-[#131826]/70 backdrop-blur-md border border-white/5 hover:border-white/10 hover:-translate-y-0.5 transition-all shadow-xl">
            <div className="flex items-center justify-between mb-4">
              <span className="text-[11px] font-mono font-bold tracking-wider text-slate-400 uppercase">{st.title}</span>
              <div className={`p-2 rounded-lg ${
                st.icon === "ShieldAlert" ? "bg-red-500/10 text-red-400" :
                st.icon === "Database" ? "bg-cyan-500/10 text-cyan-400" :
                st.icon === "Sparkles" ? "bg-amber-500/10 text-amber-400" :
                "bg-indigo-500/10 text-indigo-400"
              }`}>
                {st.icon === "ShieldAlert" && <ShieldAlert className="w-4 h-4" />}
                {st.icon === "Database" && <Database className="w-4 h-4" />}
                {st.icon === "Sparkles" && <Sparkles className="w-4 h-4" />}
                {st.icon === "FileText" && <FileText className="w-4 h-4" />}
              </div>
            </div>
            <div className="space-y-1.5">
              <div className="text-2xl font-bold font-display text-white tracking-tight">{st.value}</div>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-500 font-mono font-medium">
                <span className={st.trend === "up" ? "text-emerald-400" : "text-slate-500"}>
                  {st.change}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Grid: Recent Files & Activities */}
      <div id="dashboard-main-grid" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Recent Files Table (Left 8 columns) */}
        <div className="lg:col-span-8 p-6 rounded-2xl bg-[#131826]/60 backdrop-blur-md border border-white/5 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold font-display text-white">Loaded Lab Datasets</h3>
              <p className="text-[11px] text-slate-500 font-medium">Currently cached in local session reservoir</p>
            </div>
            <button 
              onClick={() => onNavigate(Tab.Library)}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 inline-flex items-center gap-1 transition-colors"
            >
              Browse Library
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-white/5 text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest">
                  <th className="pb-3 font-semibold">File Name & Type</th>
                  <th className="pb-3 font-semibold">Uploaded</th>
                  <th className="pb-3 font-semibold">Status Badge</th>
                  <th className="pb-3 font-semibold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                {files.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-slate-500 font-mono">
                      No files uploaded in this session yet. Click "Upload New Genome" above.
                    </td>
                  </tr>
                ) : (
                  files.slice(0, 5).map((fl) => (
                    <tr key={fl.id} className="hover:bg-white/[0.01] transition-colors group">
                      <td className="py-3.5 pr-3">
                        <div className="flex items-center gap-3">
                          <div className={`p-2 rounded-lg font-mono font-bold text-[10px] ${
                            fl.type === "fasta" ? "bg-indigo-500/10 text-indigo-300" :
                            fl.type === "vcf" ? "bg-cyan-500/10 text-cyan-300" :
                            fl.type === "ast" ? "bg-amber-500/10 text-amber-300" :
                            fl.type === "paper" ? "bg-emerald-500/10 text-emerald-300" :
                            "bg-slate-500/10 text-slate-300"
                          }`}>
                            {fl.type.toUpperCase()}
                          </div>
                          <div className="space-y-0.5">
                            <span className="font-semibold text-slate-200 block truncate max-w-[240px] group-hover:text-indigo-400 transition-colors">
                              {fl.name}
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono">
                              {(fl.size / 1024).toFixed(1)} KB
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3.5 text-slate-400 font-mono text-[11px]">
                        {fl.uploadedAt}
                      </td>
                      <td className="py-3.5">
                        <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-medium font-mono ${
                          fl.status === "analyzed" ? "bg-emerald-500/10 text-emerald-400" :
                          fl.status === "processing" ? "bg-indigo-500/10 text-indigo-400 animate-pulse" :
                          "bg-red-500/10 text-red-400"
                        }`}>
                          {fl.status === "analyzed" ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                          {fl.status === "analyzed" ? "Analyzed" : "Processing"}
                        </span>
                      </td>
                      <td className="py-3.5 text-right">
                        <button
                          onClick={() => onSelectFile(fl)}
                          className="px-2.5 py-1 text-[11px] font-semibold text-slate-300 hover:text-indigo-400 bg-white/5 hover:bg-white/10 rounded-md transition-all border border-white/5"
                        >
                          View Analysis
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent Activity Timeline (Right 4 columns) */}
        <div className="lg:col-span-4 p-6 rounded-2xl bg-[#131826]/60 backdrop-blur-md border border-white/5 space-y-6 flex flex-col justify-between">
          <div className="space-y-5">
            <div>
              <h3 className="text-base font-semibold font-display text-white">Resistance Surveillance Timeline</h3>
              <p className="text-[11px] text-slate-500 font-medium font-mono">LAB INTEGRITY CHRONICLE</p>
            </div>
            
            <div className="space-y-5 relative pl-4 border-l border-white/5">
              {activities.map((act) => (
                <div key={act.id} className="relative space-y-1">
                  {/* Timeline dot custom coloring */}
                  <span className={`absolute -left-[21.5px] top-1.5 w-2 h-2 rounded-full border-2 ${
                    act.type === "success" ? "bg-emerald-400 border-emerald-400/30" :
                    act.type === "danger" ? "bg-red-400 border-red-400/30" :
                    act.type === "warning" ? "bg-amber-400 border-amber-400/30" :
                    "bg-indigo-400 border-indigo-400/30"
                  }`} />
                  
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-200">{act.title}</span>
                    <span className="text-[9px] text-slate-500 font-mono">{act.time}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-relaxed font-normal">
                    {act.text}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-white/5">
            <div className="flex items-center gap-3 p-3 bg-red-500/5 hover:bg-red-500/10 border border-red-500/10 rounded-xl transition-colors">
              <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
              <div>
                <span className="text-xs font-bold text-red-300 block">NDM-5 Alert Raised</span>
                <span className="text-[9px] font-mono text-slate-500 block">IncX3 high-risk transconjugants identified in local wastewater isolate profile.</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions Panel */}
      <div id="quick-actions-panel" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          onClick={() => onNavigate(Tab.Upload)}
          className="p-5 rounded-xl border border-white/5 bg-[#131826]/30 hover:bg-[#131826]/80 hover:border-indigo-500/30 text-left transition-all group cursor-pointer"
        >
          <Plus className="w-5 h-5 text-indigo-400 group-hover:scale-105 transition-transform mb-3" />
          <span className="text-xs font-semibold text-slate-200 block mb-1">Upload New File</span>
          <span className="text-[11px] text-slate-500 font-medium block">Drag FASTA, VCF, AST data</span>
        </button>

        <button
          onClick={() => onNavigate(Tab.Chat)}
          className="p-5 rounded-xl border border-white/5 bg-[#131826]/30 hover:bg-[#131826]/80 hover:border-cyan-500/30 text-left transition-all group cursor-pointer"
        >
          <MessageSquare className="w-5 h-5 text-cyan-400 group-hover:scale-105 transition-transform mb-3" />
          <span className="text-xs font-semibold text-slate-200 block mb-1">Start Gemini Chat</span>
          <span className="text-[11px] text-slate-500 font-medium block">Ask natural language AMR questions</span>
        </button>

        <button
          onClick={() => onNavigate(Tab.Reports)}
          className="p-5 rounded-xl border border-white/5 bg-[#131826]/30 hover:bg-[#131826]/80 hover:border-emerald-500/30 text-left transition-all group cursor-pointer"
        >
          <FileText className="w-5 h-5 text-emerald-400 group-hover:scale-105 transition-transform mb-3" />
          <span className="text-xs font-semibold text-slate-200 block mb-1">Generate Report</span>
          <span className="text-[11px] text-slate-500 font-medium block">Formulate dossiers & summaries</span>
        </button>

        <button
          onClick={() => onNavigate(Tab.Trends)}
          className="p-5 rounded-xl border border-white/5 bg-[#131826]/30 hover:bg-[#131826]/80 hover:border-amber-500/30 text-left transition-all group cursor-pointer"
        >
          <BookOpen className="w-5 h-5 text-amber-400 group-hover:scale-105 transition-transform mb-3" />
          <span className="text-xs font-semibold text-slate-200 block mb-1">Resistance Trends</span>
          <span className="text-[11px] text-slate-500 font-medium block">Explore heatmaps & datasets</span>
        </button>
      </div>
    </div>
  );
}
