import React, { useState, useRef } from "react";
import { UploadCloud, File, AlertCircle, CheckCircle2, ChevronRight, Activity, ArrowRight, Dna } from "lucide-react";
import { ResearchFile, FileType } from "../types";

// Standard sample configurations to quick-insert if user doesn't have local FASTA files
interface SandboxTemplate {
  name: string;
  type: FileType;
  size: number;
  content: string;
  desc: string;
}

const TEMPLATES: SandboxTemplate[] = [
  {
    name: "Enterobacter_cloacae_blaNDM-1_surveillance.fasta",
    type: "fasta",
    size: 15400,
    desc: "Carbapenemase sequence assembly",
    content: `>blaNDM-1 complete gene clone
ATGGAATTGCCCAATATTATGCACCCGGTCGCGAAGCTGAGCACCCTGGCAGCGGCGCTGGCTGTCGGCG
TGGCGGGCGCGGGGGCGGTACTGGCATTCGGCGGCTTGGCTGGCGCCGATGCGCAGCAGACGACGGCAGA
TTTGGCAGAGCGTCAGAGTCAGGAGGTCAGAGAGGTGCTGCAGCAGCCTGCGGTCGCGACGACACCGCAA`
  },
  {
    name: "S_aureus_linezolid_resistance_pbp_variations.vcf",
    type: "vcf",
    size: 2100,
    desc: "High-impact variant draft list",
    content: `##fileformat=VCFv4.2
#CHROM	POS	ID	REF	ALT	QUAL	FILTER	INFO
Chr1	839211	.	G	T	999	PASS	DP=40;GENE=23SR_RNA;CONSEQUENCE=missense;MUTATION=G2576T`
  },
  {
    name: "Neisseria_gonorrhoeae_cephalosporin_MIC_AST.ast",
    type: "ast",
    size: 890,
    desc: "Ceftriaxone & Penicillin MIC markers",
    content: `CRO:R,PEN:R,CIP:R,AZM:I,TET:R`
  }
];

interface UploadWorkspaceProps {
  onAddFile: (file: ResearchFile) => void;
  files: ResearchFile[];
  onNavigateToAnalysis: (file: ResearchFile) => void;
}

type StepStatus = "idle" | "parsing" | "extracting" | "database" | "complete" | "error";

export default function UploadWorkspace({ onAddFile, files, onNavigateToAnalysis }: UploadWorkspaceProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [selectedLocalFile, setSelectedLocalFile] = useState<File | null>(null);
  const [pastedContent, setPastedContent] = useState("");
  const [customName, setCustomName] = useState("");
  const [detectedType, setDetectedType] = useState<FileType>("fasta");

  // Multi-step AI processing animation state
  const [processingFile, setProcessingFile] = useState<ResearchFile | null>(null);
  const [stepStatus, setStepStatus] = useState<StepStatus>("idle");
  const [stepProgress, setStepProgress] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Helper detect type from extension or raw string
  const autoDetectType = (name: string, content: string): FileType => {
    const ext = name.split(".").pop()?.toLowerCase();
    if (ext === "fasta" || ext === "fa" || ext === "fna") return "fasta";
    if (ext === "vcf") return "vcf";
    if (ext === "ast" || ext === "csv") return "ast";
    if (ext === "pdf" || ext === "doc" || ext === "docx") return "paper";
    if (ext === "txt" && content.includes(">")) return "fasta";
    if (ext === "txt" && content.includes("CHROM")) return "vcf";
    if (content.includes(">")) return "fasta";
    if (content.includes("##fileformat=VCF")) return "vcf";
    if (content.includes(":") && content.includes(",")) return "ast";
    return "genelist";
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const processSelectedFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string || "";
      const type = autoDetectType(file.name, text);
      
      const newFile: ResearchFile = {
        id: "usr-" + Date.now(),
        name: file.name,
        size: file.size,
        type: type,
        uploadedAt: new Date().toISOString().replace("T", " ").substring(0, 16),
        status: "processing",
        progress: 0,
        content: text
      };
      
      onAddFile(newFile);
      triggerAIPipeline(newFile);
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processSelectedFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processSelectedFile(e.target.files[0]);
    }
  };

  // Trigger loading state of template
  const loadSandboxTemplate = (tpl: SandboxTemplate) => {
    const newFile: ResearchFile = {
      id: "tpl-" + Math.random().toString(36).substring(4),
      name: tpl.name,
      size: tpl.size,
      type: tpl.type,
      uploadedAt: new Date().toISOString().replace("T", " ").substring(0, 16),
      status: "processing",
      progress: 0,
      content: tpl.content
    };
    onAddFile(newFile);
    triggerAIPipeline(newFile);
  };

  // Pasted manual entry submit
  const handlePastedSubmit = () => {
    if (!pastedContent.trim()) return;
    const nameStr = customName.trim() || `Raw_Genomic_Input_${Date.now().toString().slice(-4)}.txt`;
    const type = autoDetectType(nameStr, pastedContent);
    const newFile: ResearchFile = {
      id: "pst-" + Date.now(),
      name: nameStr,
      size: pastedContent.length,
      type: type,
      uploadedAt: new Date().toISOString().replace("T", " ").substring(0, 16),
      status: "processing",
      progress: 0,
      content: pastedContent
    };
    onAddFile(newFile);
    triggerAIPipeline(newFile);
    // clean
    setPastedContent("");
    setCustomName("");
  };

  // Simulated stepper to give premium UI pipeline transparency
  const triggerAIPipeline = (file: ResearchFile) => {
    setProcessingFile(file);
    setStepStatus("parsing");
    setStepProgress(20);

    setTimeout(() => {
      setStepStatus("extracting");
      setStepProgress(50);
      file.progress = 50;

      setTimeout(() => {
        setStepStatus("database");
        setStepProgress(85);
        file.progress = 85;

        setTimeout(() => {
          // Trigger actual API call on the server
          callExpressAnalyzeAPI(file);
        }, 1200);
      }, 1200);
    }, 1000);
  };

  const callExpressAnalyzeAPI = async (file: ResearchFile) => {
    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileType: file.type,
          fileName: file.name,
          fileContent: file.content
        })
      });

      const data = await response.json();
      if (data.success) {
        file.status = "analyzed";
        file.progress = 100;
        file.analysisResult = data.analysis;
        setStepStatus("complete");
        setStepProgress(100);
      } else {
        file.status = "error";
        file.progress = 100;
        file.errorMessage = data.error;
        setStepStatus("error");
      }
    } catch (err: any) {
      file.status = "error";
      file.progress = 100;
      file.errorMessage = err.message || "Failed to reach server-side proxy.";
      setStepStatus("error");
    }
  };

  return (
    <div id="upload-workspace-container" className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      
      {/* File Ingestion Left Section (7 Columns) */}
      <div className="lg:col-span-7 space-y-8">
        <div>
          <h2 className="text-xl font-display font-medium text-white tracking-tight">Upload Scientific Data</h2>
          <p className="text-xs text-slate-400">
            Submit your research raw metrics. Gemini AI parses sequences, lists, and tables immediately.
          </p>
        </div>

        {/* Drag and Drop Zone */}
        <div
          id="drag-drop-zone"
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`p-10 rounded-2xl border-2 border-dashed text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-4 ${
            isDragging
              ? "border-indigo-400 bg-indigo-500/5 glow-indigo"
              : "border-slate-800 bg-[#131826]/30 hover:bg-[#131826]/50 hover:border-slate-700"
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            onChange={handleFileSelect}
          />
          <div className="p-4 rounded-full bg-slate-900 border border-white/5 shadow-inner text-indigo-400 group-hover:scale-110 transition-transform">
            <UploadCloud className="w-8 h-8" />
          </div>
          <div>
            <span className="text-xs font-semibold text-slate-200 block mb-1">Drag & drop files or click to browse</span>
            <span className="text-[10px] text-slate-500 font-mono block">Supports: FASTA, VCF, CSV, CSV/AST tables, PDFs</span>
          </div>
        </div>

        {/* Manual Input Paste Board */}
        <div className="p-6 rounded-2xl bg-[#131826]/60 backdrop-blur-md border border-white/5 space-y-4">
          <div>
            <h4 className="text-xs font-bold text-white font-mono uppercase tracking-wider">Paste Sequence Or Tabular Values</h4>
            <p className="text-[10px] text-slate-500">Quickly feed raw nucleotide strings or variant parameters without saving files locally.</p>
          </div>
          <div className="space-y-3">
            <input
              type="text"
              placeholder="Descriptive name (e.g., Shigella_flexneri_OXA_sequence.fna)"
              value={customName}
              onChange={(e) => setCustomName(e.target.value)}
              className="w-full px-3 py-2 bg-slate-900/80 border border-slate-800 rounded-lg text-xs placeholder:text-slate-600 focus:outline-none focus:border-indigo-500/50 text-slate-200 font-mono"
            />
            <textarea
              placeholder="Paste sequence/VCF row. e.g. >blaCTX-M-9\nATGGTGACAAAG..."
              value={pastedContent}
              onChange={(e) => setPastedContent(e.target.value)}
              rows={4}
              className="w-full px-3 py-2 bg-slate-900/80 border border-slate-800 rounded-lg text-xs placeholder:text-slate-600 focus:outline-none focus:border-indigo-500/50 text-slate-200 font-mono"
            />
            <button
              onClick={handlePastedSubmit}
              disabled={!pastedContent.trim()}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-lg text-xs font-semibold transition-all flex items-center justify-center gap-1 cursor-pointer"
            >
              Parse Pasted Input
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Sandbox Pre-loaded Files */}
        <div className="space-y-3">
          <span className="text-[10px] font-mono font-bold text-slate-500 tracking-widest block uppercase">Biomedical Sandbox Presets</span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {TEMPLATES.map((tpl, idx) => (
              <div 
                key={idx}
                onClick={() => loadSandboxTemplate(tpl)}
                className="p-4 rounded-xl border border-white/5 bg-[#131826]/20 hover:bg-[#131826]/70 hover:border-cyan-500/30 transition-all cursor-pointer space-y-2 group text-left"
              >
                <div className="flex items-center justify-between">
                  <span className="px-1.5 py-0.5 rounded text-[8px] font-bold font-mono bg-indigo-500/15 text-indigo-300">
                    {tpl.type.toUpperCase()}
                  </span>
                  <Dna className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 transition-colors" />
                </div>
                <div>
                  <span className="text-[11px] font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors block truncate">{tpl.name}</span>
                  <span className="text-[9px] text-slate-500 font-mono block">{tpl.desc}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Live pipeline stepper right layout (5 Columns) */}
      <div className="lg:col-span-5 p-6 rounded-2xl bg-[#131826]/60 backdrop-blur-md border border-white/5 space-y-6 flex flex-col justify-between">
        <div className="space-y-6">
          <div>
            <h3 className="text-base font-semibold font-display text-white">Genomic Sequencing Stepper</h3>
            <p className="text-[11px] text-slate-500 font-medium">Observe raw parser routing live logs</p>
          </div>

          {processingFile && stepStatus !== "idle" ? (
            <div className="space-y-6">
              {/* Active file brief */}
              <div className="p-4 bg-slate-900/60 rounded-xl border border-white/5 flex items-center gap-3">
                <File className="w-8 h-8 text-indigo-400 shrink-0" />
                <div className="min-w-0">
                  <span className="text-xs font-bold text-slate-200 block truncate">{processingFile.name}</span>
                  <span className="text-[10px] text-slate-500 font-mono block uppercase">TYPE: {processingFile.type}</span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px] font-mono text-slate-400">
                  <span>Pipeline Progress</span>
                  <span>{stepProgress}%</span>
                </div>
                <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-indigo-500 to-cyan-400 transition-all duration-500 rounded-full"
                    style={{ width: `${stepProgress}%` }}
                  />
                </div>
              </div>

              {/* Steps visual flow */}
              <div className="space-y-4">
                {/* Step 1 */}
                <div className="flex items-start gap-3">
                  <div className={`mt-0.5 p-1 rounded-full ${
                    stepStatus === "parsing" ? "text-indigo-400 animate-spin" :
                    ["extracting", "database", "complete"].includes(stepStatus) ? "bg-emerald-500/10 text-emerald-400" :
                    "text-slate-600"
                  }`}>
                    {["extracting", "database", "complete"].includes(stepStatus) ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      <Activity className="w-4 h-4" />
                    )}
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-200 block">Parsing nucleotides & format integrity</span>
                    <span className="text-[10px] text-slate-500 block">Autodetecting FASTA header keys or CSV row counts...</span>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="flex items-start gap-3">
                  <div className={`mt-0.5 p-1 rounded-full ${
                    stepStatus === "extracting" ? "text-indigo-400 animate-spin" :
                    ["database", "complete"].includes(stepStatus) ? "bg-emerald-500/10 text-emerald-400" :
                    "text-slate-600"
                  }`}>
                    {["database", "complete"].includes(stepStatus) ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      <Activity className="w-4 h-4 animate-pulse" />
                    )}
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-200 block">Extracting base64/multimodal parts</span>
                    <span className="text-[10px] text-slate-500 block">Streaming sequence payload arrays directly to Gemini flash model...</span>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="flex items-start gap-3">
                  <div className={`mt-0.5 p-1 rounded-full ${
                    stepStatus === "database" ? "text-indigo-400 animate-spin" :
                    ["complete"].includes(stepStatus) ? "bg-emerald-500/10 text-emerald-400" :
                    "text-slate-600"
                  }`}>
                    {["complete"].includes(stepStatus) ? (
                      <CheckCircle2 className="w-4 h-4" />
                    ) : (
                      <Activity className="w-4 h-4" />
                    )}
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-200 block">Intersecting reference library targets</span>
                    <span className="text-[10px] text-slate-500 block">Cross-checking alignment hits with CARD and ResFinder indices...</span>
                  </div>
                </div>

                {/* Step 4 */}
                <div className="flex items-start gap-3">
                  <div className={`mt-0.5 p-1 rounded-full ${
                    stepStatus === "complete" ? "bg-emerald-500/10 text-emerald-400" :
                    stepStatus === "error" ? "bg-red-500/10 text-red-400" :
                    "text-slate-600"
                  }`}>
                    {stepStatus === "complete" ? <CheckCircle2 className="w-4 h-4" /> : <Activity className="w-4 h-4" />}
                  </div>
                  <div>
                    <span className="text-xs font-semibold text-slate-200 block">Synthesized Report compiling</span>
                    <span className="text-[10px] text-slate-500 block">Compiling Markdown sections for structural analysis panels.</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="py-12 border border-slate-800/60 rounded-xl relative overflow-hidden flex flex-col items-center justify-center text-center p-6 bg-slate-900/20">
              <AlertCircle className="w-8 h-8 text-slate-600 mb-3" />
              <span className="text-xs font-bold text-slate-400 block mb-1">Pipeline Idle</span>
              <span className="text-[10px] text-slate-500 max-w-xs leading-relaxed block">
                Select a sandbox preset or complete a raw file upload to trigger the live sequencing stepper logs here.
              </span>
            </div>
          )}
        </div>

        {stepStatus === "complete" && processingFile && (
          <button
            onClick={() => onNavigateToAnalysis(processingFile)}
            className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:opacity-95 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow-lg cursor-pointer"
          >
            Review AI Decoupled Workspace
            <ArrowRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        )}
      </div>
    </div>
  );
}
