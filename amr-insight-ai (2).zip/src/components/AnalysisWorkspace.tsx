import React, { useState, useMemo } from "react";
import { 
  FileText, ArrowDown, ChevronRight, CheckCircle2, AlertTriangle, 
  Search, SlidersHorizontal, Info, Layers, RefreshCw, ZoomIn, ZoomOut, Maximize2 
} from "lucide-react";
import { ResearchFile, ASTRecord, VariantMutation, GeneRecord } from "../types";
import { MOCK_AST_TABLE, MOCK_VCF_RECORDS, MOCK_GENES } from "../initialData";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

interface AnalysisWorkspaceProps {
  files: ResearchFile[];
  selectedFile: ResearchFile | null;
  onSelectFile: (file: ResearchFile | null) => void;
  onNavigateToChat: () => void;
}

export default function AnalysisWorkspace({ files, selectedFile, onSelectFile, onNavigateToChat }: AnalysisWorkspaceProps) {
  // If no file is explicitly selected, let's default to the first analyzed file
  const activeFile = selectedFile || files.find(f => f.status === "analyzed") || null;
  
  // Local active tab within analysis (for switching between types if desired)
  const currentType = activeFile ? activeFile.type : "fasta";

  // VCF interactions
  const [selectedVcfRow, setSelectedVcfRow] = useState<VariantMutation | null>(MOCK_VCF_RECORDS[0]);
  const [vcfSearch, setVcfSearch] = useState("");

  // Gene List Multi-Select for Comparison Mode
  const [selectedComparisonGenes, setSelectedComparisonGenes] = useState<string[]>(["g1", "g2"]);

  // PDF ask inline simulator
  const [pdfAskQuery, setPdfAskQuery] = useState("");
  const [pdfAnswers, setPdfAnswers] = useState<Array<{ q: string; a: string }>>([
    {
      q: "What was the transfer rate of NDM-5 plasmid in this study?",
      a: "The IncX3 plasmid carrying blaNDM-5 demonstrated high conjugative transfer frequencies ranging from 10^-3 to 10^-1 transconjugants per donor cell at 25°C."
    }
  ]);
  const [isAskingPdf, setIsAskingPdf] = useState(false);

  // Protein Zoom State
  const [proteinZoom, setProteinZoom] = useState(100);
  const [activeHotspot, setActiveHotspot] = useState<string>("hotspot-e104");

  // Filter VCF rows
  const filteredVcfRecords = useMemo(() => {
    return MOCK_VCF_RECORDS.filter(rec => 
      rec.gene.toLowerCase().includes(vcfSearch.toLowerCase()) || 
      rec.codonMutation.toLowerCase().includes(vcfSearch.toLowerCase())
    );
  }, [vcfSearch]);

  const handleToggleGeneComparison = (id: string) => {
    if (selectedComparisonGenes.includes(id)) {
      if (selectedComparisonGenes.length > 2) {
        setSelectedComparisonGenes(selectedComparisonGenes.filter(gid => gid !== id));
      }
    } else {
      setSelectedComparisonGenes([...selectedComparisonGenes, id]);
    }
  };

  const handleAskInlinePdf = async () => {
    if (!pdfAskQuery.trim()) return;
    setIsAskingPdf(true);
    const queryTemp = pdfAskQuery;
    setPdfAskQuery("");

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [
            { role: "user", content: `Regarding the literature file "${activeFile?.name || 'literature article'}", answer this specific question: ${queryTemp}` }
          ],
          activeFileContext: activeFile
        })
      });
      const data = await response.json();
      if (data.success) {
        setPdfAnswers([{ q: queryTemp, a: data.message }, ...pdfAnswers]);
      } else {
        setPdfAnswers([{ q: queryTemp, a: "Error: " + data.error }, ...pdfAnswers]);
      }
    } catch {
      setPdfAnswers([{ q: queryTemp, a: "Failed to connect to AI server. Please retry." }, ...pdfAnswers]);
    } finally {
      setIsAskingPdf(false);
    }
  };

  // Recharts representation for susceptibility distribution
  const chartData = useMemo(() => {
    const counts = { R: 0, I: 0, S: 0 };
    MOCK_AST_TABLE.forEach(r => counts[r.sir]++);
    return [
      { name: "Resistant (R)", count: counts.R, fill: "#F87171" },
      { name: "Intermediate (I)", count: counts.I, fill: "#FBBF24" },
      { name: "Susceptible (S)", count: counts.S, fill: "#34D399" }
    ];
  }, []);

  return (
    <div id="analysis-workspace-root" className="space-y-6">
      
      {/* Workspace Header File Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl bg-[#131826]/40 border border-white/5">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-indigo-600/10 text-indigo-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Active Lab Dataset</span>
            {activeFile ? (
              <span className="text-sm font-semibold text-white tracking-wider flex items-center gap-2">
                {activeFile.name}
                <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold bg-indigo-500/20 text-indigo-300 rounded border border-indigo-500/10">
                  {activeFile.type.toUpperCase()}
                </span>
              </span>
            ) : (
              <span className="text-sm text-slate-500">No datasets uploaded yet select from sandbox upload</span>
            )}
          </div>
        </div>

        {/* Picker Dropdown */}
        <div className="flex gap-2">
          <select
            value={activeFile ? activeFile.id : ""}
            onChange={(e) => {
              const matched = files.find(f => f.id === e.target.value);
              if (matched) onSelectFile(matched);
            }}
            className="px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs font-semibold text-slate-200 outline-none focus:border-indigo-500/60"
          >
            <option value="" disabled>Select isolate stream...</option>
            {files.map(f => (
              <option key={f.id} value={f.id}>{f.name} ({f.type.toUpperCase()})</option>
            ))}
          </select>
        </div>
      </div>

      {/* Conditionally Render Analysis Modules */}
      {!activeFile ? (
        <div className="py-20 border border-dashed border-slate-800 rounded-2xl flex flex-col items-center justify-center text-center p-6 bg-slate-900/10">
          <Info className="w-10 h-10 text-slate-600 mb-4" />
          <h3 className="text-lg font-semibold font-display text-white mb-2">No Isolate Analyzed Yet</h3>
          <p className="text-xs text-slate-400 max-w-sm leading-relaxed mb-6">
            Please head over to the **Upload Workspace** to submit a sequence or pick a sandbox template to begin real-time mutational analyses.
          </p>
        </div>
      ) : (
        <div id="module-display">
          
          {/* A) FASTA ANALYSIS MOLECULE */}
          {currentType === "fasta" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Sequence highlight base viewer */}
              <div className="lg:col-span-7 bg-[#131826]/50 p-6 rounded-2xl border border-white/5 space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-semibold font-display text-white">Nucleotide Sequence Alignment Map</h3>
                  <span className="text-[10px] font-mono text-slate-500">FASTA Sequence Layout</span>
                </div>
                
                {/* Colored nucleotide boxes */}
                <div className="p-4 bg-slate-950 rounded-xl border border-white/5 font-mono text-xs leading-relaxed select-all overflow-y-auto max-h-[360px] tracking-widest break-all">
                  {activeFile.content.split("\n").map((line, lIdx) => {
                    if (line.startsWith(">")) {
                      return <div key={lIdx} className="text-cyan-400 mb-2 font-semibold select-none">{line}</div>;
                    }
                    return (
                      <div key={lIdx} className="opacity-90">
                        {Array.from(line).map((char, cIdx) => {
                          const lower = char.toUpperCase();
                          let colorCls = "text-slate-400";
                          if (lower === "A") colorCls = "text-emerald-400 bg-emerald-500/10 font-bold px-0.5";
                          else if (lower === "T") colorCls = "text-rose-400 bg-rose-500/10 font-bold px-0.5";
                          else if (lower === "G") colorCls = "text-amber-400 bg-amber-500/10 font-bold px-0.5";
                          else if (lower === "C") colorCls = "text-cyan-400 bg-cyan-500/10 font-bold px-0.5";
                          return <span key={cIdx} className={colorCls}>{char}</span>;
                        })}
                      </div>
                    );
                  })}
                </div>
                <div className="flex justify-between items-center text-[10px] font-mono text-slate-500">
                  <div className="flex gap-4">
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-emerald-500/20 rounded inline-block border border-emerald-400/30"></span> Adenine (A)</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-rose-500/20 rounded inline-block border border-rose-400/30"></span> Thymine (T)</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-amber-500/20 rounded inline-block border border-amber-400/30"></span> Guanine (G)</span>
                    <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 bg-cyan-500/20 rounded inline-block border border-cyan-400/30"></span> Cytosine (C)</span>
                  </div>
                </div>
              </div>

              {/* Homology matching alignment summaries (5 Columns) */}
              <div className="lg:col-span-5 bg-[#131826]/70 p-6 rounded-2xl border border-white/5 space-y-6">
                <div>
                  <h3 className="text-sm font-semibold font-display text-white">CARD Database Homology Findings</h3>
                  <p className="text-[11px] text-slate-500">Gemini synthesis on matching resistance targets</p>
                </div>

                <div className="markdown-body text-xs text-slate-300 leading-relaxed font-sans bg-slate-950/40 p-4 rounded-xl border border-white/5 divide-y divide-white/5 space-y-4">
                  {/* Safely print Gemini generated summaries */}
                  <div className="whitespace-pre-line text-slate-300 font-sans">
                    {activeFile.analysisResult || "No alignment details retrieved."}
                  </div>
                </div>

                <div className="pt-4 border-t border-white/5 flex gap-3">
                  <button
                    onClick={onNavigateToChat}
                    className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold transition-all flex items-center justify-center gap-1 cursor-pointer"
                  >
                    Consult Gemini on this Gene
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* B) VCF MUTATION AND VARIANT GRADING */}
          {currentType === "vcf" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* VCF Table (7 Columns) */}
                <div className="lg:col-span-7 bg-[#131826]/50 p-6 rounded-2xl border border-white/5 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="text-sm font-semibold font-display text-white">Genomic Mutation Catalog</h3>
                      <p className="text-[11px] text-slate-500">Parsed SNPs in core resistance determinants</p>
                    </div>
                    
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-slate-500" />
                      <input
                        type="text"
                        placeholder="Search gene/variant..."
                        value={vcfSearch}
                        onChange={(e) => setVcfSearch(e.target.value)}
                        className="pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs outline-none focus:border-indigo-500/50 text-slate-200"
                      />
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b border-white/5 text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest">
                          <th className="pb-2">Location & Gene</th>
                          <th className="pb-2">Change</th>
                          <th className="pb-2">Relevance</th>
                          <th className="pb-2 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                        {filteredVcfRecords.map((m) => (
                          <tr 
                            key={m.id}
                            onClick={() => setSelectedVcfRow(m)}
                            className={`hover:bg-white/[0.02] transition-colors cursor-pointer ${
                              selectedVcfRow?.id === m.id ? "bg-indigo-500/5 text-white" : ""
                            }`}
                          >
                            <td className="py-2.5 pr-2">
                              <div className="font-semibold">{m.gene}</div>
                              <div className="text-[9px] text-slate-500 font-mono">{m.chromosome}:{m.position}</div>
                            </td>
                            <td className="py-2.5 font-mono text-[11px]">
                              {m.codonMutation} <span className="text-slate-500">({m.refAlt})</span>
                            </td>
                            <td className="py-2.5">
                              <span className={`inline-block px-1.5 py-0.5 rounded text-[9px] font-mono font-bold ${
                                m.relevance === "AMR-Conferring" ? "bg-red-500/10 text-red-400" :
                                m.relevance === "Unknown" ? "bg-amber-500/10 text-amber-400" :
                                "bg-emerald-500/10 text-emerald-400"
                              }`}>
                                {m.relevance}
                              </span>
                            </td>
                            <td className="py-2.5 text-right font-mono text-[11px]">
                              <span className="text-slate-500">Pathogenicity: </span>
                              <span className={`font-bold ${
                                m.severityScore >= 80 ? "text-red-400" :
                                m.severityScore >= 40 ? "text-amber-400" :
                                "text-emerald-400"
                              }`}>
                                {m.severityScore}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Drawers highlighting target codon specifics (5 Columns) */}
                <div className="lg:col-span-5 bg-[#131826]/70 p-6 rounded-2xl border border-white/5 space-y-6">
                  {selectedVcfRow ? (
                    <div className="space-y-6">
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-indigo-400 font-mono uppercase tracking-wider">{selectedVcfRow.gene} Specifics</span>
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-bold font-mono bg-slate-900 border border-white/5 text-slate-400">
                            {selectedVcfRow.consequence}
                          </span>
                        </div>
                        <h4 className="text-lg font-bold text-white font-display">Substitution {selectedVcfRow.codonMutation}</h4>
                        <p className="text-[11px] text-slate-400 font-mono">{selectedVcfRow.chromosome} position: {selectedVcfRow.position}</p>
                      </div>

                      {/* Severity slide bar */}
                      <div className="space-y-2">
                        <div className="flex justify-between items-center text-[10px] font-mono text-slate-500 uppercase">
                          <span>Mutation Threat index</span>
                          <span className="font-bold text-slate-300">{selectedVcfRow.severityScore} / 100</span>
                        </div>
                        <div className="h-2 w-full bg-slate-900 rounded-full overflow-hidden relative border border-white/5">
                          <div 
                            className="absolute top-0 left-0 h-full bg-gradient-to-r from-emerald-500 via-amber-400 to-red-500 transition-all rounded-full"
                            style={{ width: `${selectedVcfRow.severityScore}%` }}
                          />
                        </div>
                      </div>

                      <div className="p-4 bg-slate-950/80 rounded-xl border border-white/5 text-xs text-slate-300 space-y-3 leading-relaxed">
                        <div className="flex items-start gap-2 text-amber-400 font-semibold mb-1">
                          <Info className="w-4 h-4 shrink-0 mt-0.5" />
                          <span>Mechanism Explanation</span>
                        </div>
                        <p>{selectedVcfRow.explanation || activeFile.analysisResult}</p>
                      </div>

                      <div className="pt-4 border-t border-white/5 flex gap-2">
                        <button
                          onClick={onNavigateToChat}
                          className="w-full py-2.5 bg-slate-900 hover:bg-slate-950 border border-slate-800 text-slate-300 rounded-xl text-xs font-semibold transition-all text-center block"
                        >
                          Consult Gemini On Pathway
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="py-20 text-center text-slate-500 font-mono text-xs">
                      Select a mutation row on the left component to investigate codon effects.
                    </div>
                  )}
                </div>

              </div>
            </div>
          )}

          {/* C) PDF LITERATURE EVIDENCE EXPLOITER */}
          {currentType === "paper" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left PDF Abstract / Reader mockup (7 Columns) */}
              <div className="lg:col-span-7 bg-[#131826]/50 p-6 rounded-2xl border border-white/5 space-y-4 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-sm font-semibold font-display text-white">Literature Sourced Manuscript Excerpt</h3>
                      <p className="text-[11px] text-slate-500">Draggables / select to analyze with Gemini context</p>
                    </div>
                    <span className="text-[9px] font-mono font-bold bg-emerald-500/10 text-emerald-300 px-1.5 py-0.5 rounded border border-emerald-500/25">
                      PDF VIEWER
                    </span>
                  </div>

                  <div className="p-5 bg-slate-950/80 rounded-xl border border-white/5 text-xs text-slate-300 leading-relaxed font-sans min-h-[300px] select-text">
                    <span className="font-semibold text-slate-400 block mb-2 underline decoration-indigo-400">Section 2.3: Intersecting plasmid conjugation in Enterobacteriaceae</span>
                    "Here we outline the conjugal dissemination variables relative to Class A and Class B carbapenemase isolates. High frequency conjugations observed in E. coli ST131 clones was attributed to highly mobile ISEcp1 upstream flanking cassettes. The blaCTX-M-15 cluster demonstrates massive dissemination kinetics, notably higher than blaNDM-1 variants on IncFII assemblies in stagnant wastewater samples at temperatures below 22°C. These structures present immediate challenge to cephalosporin therapeutics..."
                  </div>

                  <div className="p-3 bg-indigo-500/5 rounded-lg border border-indigo-500/10 text-[11px] text-indigo-300 flex items-center gap-2">
                    <SlidersHorizontal className="w-4 h-4 shrink-0" />
                    <span>Selected text context is automatically captured in inline queries below.</span>
                  </div>
                </div>

                {/* Highlight and ask inline controller */}
                <div className="pt-4 border-t border-slate-800 space-y-3">
                  <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider block">Ask Inline Gemini Helper</span>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g. Does blaNDM-1 show resistance to clavulanate?"
                      value={pdfAskQuery}
                      onChange={(e) => setPdfAskQuery(e.target.value)}
                      className="flex-1 px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-200 outline-none focus:border-indigo-500/50"
                      onKeyDown={(e) => e.key === "Enter" && handleAskInlinePdf()}
                    />
                    <button
                      onClick={handleAskInlinePdf}
                      disabled={isAskingPdf || !pdfAskQuery.trim()}
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white rounded-lg text-xs font-semibold transition-all cursor-pointer"
                    >
                      {isAskingPdf ? "Asking..." : "Ask AI"}
                    </button>
                  </div>
                </div>
              </div>

              {/* Right panel: AI Summaries & ask history (5 columns) */}
              <div className="lg:col-span-5 bg-[#131826]/70 p-6 rounded-2xl border border-white/5 space-y-6 overflow-y-auto max-h-[560px]">
                <div>
                  <h3 className="text-sm font-semibold font-display text-white">Literature Insight Summary Panel</h3>
                  <p className="text-[11px] text-slate-500">Curated abstracts & citation anchors</p>
                </div>

                <div className="space-y-4 divide-y divide-white/5">
                  <div className="whitespace-pre-line text-xs text-slate-300 font-sans leading-relaxed">
                    {activeFile.analysisResult || "Analyzing text structure..."}
                  </div>

                  {/* Ask History */}
                  <div className="pt-4 space-y-3">
                    <h4 className="text-[11px] font-mono font-bold text-slate-400 uppercase tracking-widest">Workspace Query Responses</h4>
                    {pdfAnswers.map((ans, key) => (
                      <div key={key} className="p-3.5 bg-slate-900/60 rounded-lg border border-white/5 space-y-1 text-xs">
                        <span className="font-semibold text-white block">Q: {ans.q}</span>
                        <p className="text-slate-400 font-normal leading-relaxed">{ans.a}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* D) AST CLINICAL INDICES */}
          {currentType === "ast" && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Tables (7 columns) */}
                <div className="lg:col-span-7 bg-[#131826]/50 p-6 rounded-2xl border border-white/5 space-y-4">
                  <div>
                    <h3 className="text-sm font-semibold font-display text-white">Antibiotic Susceptibility Testing (AST) Panel</h3>
                    <p className="text-[11px] text-slate-500">Mapped MIC ranges versus standard break thresholds</p>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b border-white/5 text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest">
                          <th className="pb-2">Antibiotic Base</th>
                          <th className="pb-2">Chemical Class</th>
                          <th className="pb-2 text-center">MIC Titer</th>
                          <th className="pb-2 text-right">SIR Class</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5 text-xs text-slate-300">
                        {MOCK_AST_TABLE.map((row) => (
                          <tr key={row.id} className="hover:bg-white/[0.01]">
                            <td className="py-2.5 font-semibold text-slate-200">{row.antibiotic}</td>
                            <td className="py-2.5 text-slate-400 font-normal">{row.class}</td>
                            <td className="py-2.5 text-center font-mono font-semibold">{row.mic}</td>
                            <td className="py-2.5 text-right">
                              <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
                                row.sir === "R" ? "bg-red-500/10 text-red-400 border border-red-500/10" :
                                row.sir === "I" ? "bg-amber-500/10 text-amber-400 border border-amber-500/10" :
                                "bg-emerald-500/10 text-emerald-400 border border-emerald-500/10"
                              }`}>
                                {row.sir === "R" ? "Resistant (R)" :
                                 row.sir === "I" ? "Intermediate (I)" :
                                 "Susceptible (S)"}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Stat summaries and Distribution Graphs (5 Columns) */}
                <div className="lg:col-span-5 space-y-6">
                  
                  {/* Visualizer Recharts */}
                  <div className="bg-[#131826]/70 p-6 rounded-2xl border border-white/5 space-y-4">
                    <div>
                      <h4 className="text-xs font-bold text-white font-mono uppercase tracking-wider">Phenotypic SIR Division</h4>
                      <p className="text-[10px] text-slate-500">Distribution analysis across antibiotic families</p>
                    </div>

                    <div className="h-[200px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                          <XAxis dataKey="name" tick={{ fill: "#94A3B8", fontSize: 10 }} />
                          <YAxis tick={{ fill: "#94A3B8", fontSize: 10 }} />
                          <Tooltip 
                            cursor={{ fill: "rgba(255,255,255,0.03)" }}
                            contentStyle={{ background: "#0F172A", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px" }}
                            labelStyle={{ color: "#fff", fontSize: "11px" }}
                            itemStyle={{ color: "#94A3B8", fontSize: "11px" }}
                          />
                          <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                            {chartData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.fill} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Summary card */}
                  <div className="bg-[#131826]/75 p-6 rounded-2xl border border-white/5 space-y-4 text-xs text-slate-300">
                    <div className="flex items-center gap-2 text-red-400 font-bold uppercase tracking-wider font-mono text-[11px]">
                      <AlertTriangle className="w-4 h-4" />
                      <span>MDRE / Pan-Resistant Alert</span>
                    </div>
                    <div className="whitespace-pre-line leading-relaxed bg-slate-950/40 p-4 rounded-xl border border-white/5">
                      {activeFile.analysisResult || "Compiling AST diagnostic thresholds..."}
                    </div>
                  </div>

                </div>

              </div>
            </div>
          )}

          {/* E) GENE LIST BULK EXCLUSIONS */}
          {currentType === "genelist" && (
            <div className="space-y-6">
              
              {/* Top Selector Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Table of list members (7 columns) */}
                <div className="lg:col-span-7 bg-[#131826]/50 p-6 rounded-2xl border border-white/5 space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-sm font-semibold font-display text-white">Resistance Catalog Gene List</h3>
                      <p className="text-[11px] text-slate-500">Pick 2 or more members to compare mechanism interactions</p>
                    </div>
                    <span className="text-[10px] text-indigo-400 font-mono">Select multiple checkboxes</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {MOCK_GENES.map((gene) => {
                      const isChecked = selectedComparisonGenes.includes(gene.id);
                      return (
                        <div 
                          key={gene.id}
                          onClick={() => handleToggleGeneComparison(gene.id)}
                          className={`p-4 rounded-xl border transition-all cursor-pointer ${
                            isChecked 
                              ? "bg-indigo-500/5 border-indigo-500/30 text-white" 
                              : "bg-[#131826]/20 border-white/5 text-slate-400 hover:border-slate-800"
                          }`}
                        >
                          <div className="flex items-center justify-between gap-3">
                            <div className="flex items-center gap-2.5">
                              <input
                                type="checkbox"
                                checked={isChecked}
                                onChange={() => {}} // handled by click
                                className="rounded border-slate-800 bg-slate-900 text-indigo-600 focus:ring-indigo-500"
                              />
                              <div>
                                <span className="font-mono font-bold text-slate-200 block">{gene.name}</span>
                                <span className="text-[9px] text-slate-500 block truncate max-w-[150px]">{gene.category}</span>
                              </div>
                            </div>
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-slate-900 border border-white/5 text-slate-400 font-mono">
                              CARD Ontology
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Compare view cards side-by-side (5 Columns) */}
                <div className="lg:col-span-5 bg-[#131826]/75 p-6 rounded-2xl border border-white/5 space-y-6">
                  <div>
                    <h3 className="text-sm font-semibold font-display text-white">Compare Gene Pathways</h3>
                    <p className="text-[11px] text-slate-500">Side-by-side mechanistic mapping</p>
                  </div>

                  <div className="space-y-4">
                    {MOCK_GENES.filter(g => selectedComparisonGenes.includes(g.id)).map((item) => (
                      <div key={item.id} className="p-4 bg-slate-950/80 rounded-xl border border-white/5 space-y-2 text-xs">
                        <div className="flex justify-between items-center">
                          <span className="font-mono font-bold text-indigo-400 text-sm">{item.name}</span>
                          <span className="px-1.5 py-0.5 rounded text-[9.5px] font-bold font-mono bg-emerald-500/10 text-emerald-400">
                            Confidence: {item.confidence}
                          </span>
                        </div>
                        <div className="space-y-1 text-slate-300">
                          <div>
                            <span className="text-slate-500 font-mono text-[10px] uppercase block">Suspected family</span>
                            <span className="font-medium text-[11.5px]">{item.category}</span>
                          </div>
                          <div>
                            <span className="text-slate-500 font-mono text-[10px] uppercase block">Resistence Mechanism</span>
                            <span className="font-normal text-[11px] block text-slate-400">{item.mechanism}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* F) PROTEIN STRUCTURE VIEWING & MOCKUP ZOOM */}
          {currentType === "protein" && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left protein canvas grid (7 columns) */}
              <div className="lg:col-span-7 bg-[#131826]/50 p-6 rounded-2xl border border-white/5 space-y-4 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-sm font-semibold font-display text-white">Interactive Protein Folding & Target Alignment</h3>
                      <p className="text-[11px] text-slate-500">TEM-1 Class A Beta-lactamase catalytic zone</p>
                    </div>

                    <div className="flex gap-1.5 bg-slate-900 border border-slate-800 p-1 rounded-lg">
                      <button 
                        onClick={() => setProteinZoom(Math.max(50, proteinZoom - 25))}
                        className="p-1 px-2 text-xs text-slate-400 hover:text-white hover:bg-white/5 rounded"
                      >
                        <ZoomOut className="w-3.5 h-3.5" />
                      </button>
                      <button 
                        onClick={() => setProteinZoom(Math.min(250, proteinZoom + 25))}
                        className="p-1 px-2 text-xs text-slate-400 hover:text-white hover:bg-white/5 rounded"
                      >
                        <ZoomIn className="w-3.5 h-3.5" />
                      </button>
                      <button 
                        onClick={() => setProteinZoom(100)}
                        className="p-1 px-1.5 text-[9px] font-bold font-mono text-slate-400 hover:text-white hover:bg-white/5 rounded"
                      >
                        {proteinZoom}%
                      </button>
                    </div>
                  </div>

                  {/* Inner Structural Interactive Model */}
                  <div className="relative h-[320px] bg-slate-950 rounded-xl border border-white/5 overflow-hidden flex items-center justify-center">
                    <div 
                      className="transition-transform duration-300 relative"
                      style={{ transform: `scale(${proteinZoom / 100})` }}
                    >
                      {/* Stylized geometric molecular drawing representing a protein fold */}
                      <svg viewBox="0 0 200 200" className="w-[180px] h-[180px]">
                        <defs>
                          <radialGradient id="foldGrad" cx="50%" cy="50%" r="50%">
                            <stop offset="0%" stopColor="#818CF8" stopOpacity="0.4" />
                            <stop offset="100%" stopColor="#312E81" stopOpacity="0" />
                          </radialGradient>
                        </defs>
                        <circle cx="100" cy="100" r="80" fill="url(#foldGrad)" />
                        
                        {/* Helices */}
                        <path d="M40 70 C60 20, 140 20, 160 70" fill="none" stroke="#6366F1" strokeWidth="4" strokeDasharray="5,3" />
                        <path d="M40 130 C60 180, 140 180, 160 130" fill="none" stroke="#22D3EE" strokeWidth="3" />
                        
                        {/* Beta sheet lines */}
                        <polygon points="60,95 100,65 140,95 100,125" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1.5" />
                        <line x1="100" y1="65" x2="100" y2="125" stroke="#34D399" strokeWidth="2.5" />

                        {/* Interactive hotspot locations */}
                        <g 
                          className="cursor-pointer group" 
                          onClick={() => setActiveHotspot("hotspot-e104")}
                        >
                          <circle cx="60" cy="50" r="7" fill="#F87171" className="animate-pulse" />
                          <circle cx="60" cy="50" r="12" fill="none" stroke="#F87171" strokeWidth="1" className="opacity-40 animate-ping" />
                        </g>

                        <g 
                          className="cursor-pointer group" 
                          onClick={() => setActiveHotspot("hotspot-g238")}
                        >
                          <circle cx="140" cy="110" r="7" fill="#FBBF24" />
                        </g>
                      </svg>
                    </div>

                    {/* Annotation Tags Overlay */}
                    <div className="absolute top-4 left-4 bg-slate-900/90 border border-white/5 rounded-lg p-2.5 text-[10px] space-y-1">
                      <span className="font-bold text-white uppercase block">Target Residues</span>
                      <span className="flex items-center gap-1.5 text-red-400">
                        <span className="w-1.5 h-1.5 bg-red-400 rounded-full"></span> Glu104Lys Hotspot (Active)
                      </span>
                      <span className="flex items-center gap-1.5 text-amber-400">
                        <span className="w-1.5 h-1.5 bg-amber-400 rounded-full"></span> Gly238Ser Pocket loop
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right explanation panel (5 Columns) */}
              <div className="lg:col-span-5 bg-[#131826]/70 p-6 rounded-2xl border border-white/5 space-y-6">
                <div>
                  <h3 className="text-sm font-semibold font-display text-white">Structural Folding Annotation</h3>
                  <p className="text-[11px] text-slate-500">Mutant modeling steric reviews</p>
                </div>

                <div className="space-y-4">
                  {activeHotspot === "hotspot-e104" ? (
                    <div className="p-4 bg-red-500/5 rounded-xl border border-red-500/10 space-y-2 text-xs">
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold font-mono bg-red-400/20 text-red-300">
                        GLU104LYS SUBSTITUTION
                      </span>
                      <h4 className="font-bold text-white">Omega Loop Pocket Expansion</h4>
                      <p className="text-slate-300 leading-relaxed">
                        Glu104Lys is located on the boundary of the enzymatic pocket. The substitution of a negatively charged Glutamic acid with a positively charged Lysine expands the electrostatic volume. This accommodates bulky aminopenicillin or 3rd-generation cephalosporin rings, giving rise to TEM-3 class ESBL activity.
                      </p>
                    </div>
                  ) : (
                    <div className="p-4 bg-amber-500/5 rounded-xl border border-amber-500/10 space-y-2 text-xs">
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold font-mono bg-amber-400/20 text-amber-300">
                        GLY238SER HOTSPOT
                      </span>
                      <h4 className="font-bold text-white">Steric Pathway Widening</h4>
                      <p className="text-slate-300 leading-relaxed">
                        Gly238Ser increases flexibility in the beta-strand hinges. The expanded pocket cleft yields higher turnover rates of ceftazidime, which translates to complete intermediate or high cephalosporin failure.
                      </p>
                    </div>
                  )}

                  <div className="bg-slate-950/40 p-4 rounded-xl border border-white/5 text-xs text-slate-300 space-y-3 leading-relaxed">
                    <span className="font-mono text-[10px] text-slate-500 uppercase block">Gemini Molecular Summary</span>
                    <p>{activeFile.analysisResult}</p>
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>
      )}

    </div>
  );
}
