import React, { useState, useMemo } from "react";
import { 
  Search, Grid, List, CheckCircle2, Clock, Trash2, 
  ExternalLink, Eye, SlidersHorizontal, BookOpen, AlertCircle 
} from "lucide-react";
import { ResearchFile, FileType } from "../types";

interface LibraryWorkspaceProps {
  files: ResearchFile[];
  onSelectFile: (file: ResearchFile) => void;
  onDeleteFile: (id: string) => void;
}

export default function LibraryWorkspace({ files, onSelectFile, onDeleteFile }: LibraryWorkspaceProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState<FileType | "all">("all");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  const filteredFiles = useMemo(() => {
    return files.filter(f => {
      const matchesSearch = f.name.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = selectedType === "all" || f.type === selectedType;
      return matchesSearch && matchesType;
    });
  }, [files, searchQuery, selectedType]);

  const fileTypePills: Array<{ label: string; value: FileType | "all" }> = [
    { label: "All Assays", value: "all" },
    { label: "FASTA Assemblies", value: "fasta" },
    { label: "VCF Variants", value: "vcf" },
    { label: "AST Susceptibility", value: "ast" },
    { label: "Research Literature", value: "paper" },
    { label: "Target Gene Lists", value: "genelist" },
    { label: "Protein Structures", value: "protein" }
  ];

  return (
    <div id="library-container" className="space-y-6">
      
      {/* Search and Filters toolbar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 rounded-xl bg-[#131826]/40 border border-white/5">
        
        {/* Search input bar */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search within library archives..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 outline-none focus:border-indigo-500/50"
          />
        </div>

        {/* Grid/List View Toggles */}
        <div className="flex items-center gap-4">
          <div className="flex gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-lg">
            <button
              onClick={() => setViewMode("grid")}
              className={`p-1.5 rounded transition-all ${
                viewMode === "grid" ? "bg-white/5 text-indigo-400" : "text-slate-500 hover:text-slate-300"
              }`}
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-1.5 rounded transition-all ${
                viewMode === "list" ? "bg-white/5 text-indigo-400" : "text-slate-500 hover:text-slate-300"
              }`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>

      {/* Pill Filters */}
      <div className="flex flex-wrap gap-2">
        {fileTypePills.map((pill, idx) => (
          <button
            key={idx}
            onClick={() => setSelectedType(pill.value)}
            className={`px-3 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedType === pill.value 
                ? "bg-indigo-600/10 border border-indigo-550/30 text-indigo-300" 
                : "bg-[#131826]/30 border border-white/5 text-slate-400 hover:border-slate-800"
            }`}
          >
            {pill.label}
          </button>
        ))}
      </div>

      {/* Main Files Output container */}
      {filteredFiles.length === 0 ? (
        <div className="py-20 text-center border border-dashed border-slate-800 rounded-2xl flex flex-col items-center justify-center p-6 bg-slate-900/10">
          <BookOpen className="w-10 h-10 text-slate-700 mb-3" />
          <span className="text-xs font-semibold text-slate-400 block mb-1">No matches found</span>
          <span className="text-[11px] text-slate-500">Try broadening your search term or selection filters.</span>
        </div>
      ) : viewMode === "grid" ? (
        // Grid view
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredFiles.map((file) => (
            <div
              key={file.id}
              className="p-5 rounded-2xl bg-[#131826]/60 border border-white/5 hover:border-white/10 hover:-translate-y-0.5 transition-all flex flex-col justify-between space-y-4 shadow-xl group"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <span className="px-1.5 py-0.5 rounded text-[8.5px] font-bold font-mono bg-indigo-500/15 text-indigo-400">
                    {file.type.toUpperCase()}
                  </span>
                  
                  <span className={`inline-flex items-center gap-1 text-[9px] font-mono font-bold ${
                    file.status === "analyzed" ? "text-emerald-400" : "text-amber-400"
                  }`}>
                    {file.status === "analyzed" ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3 text-spin" />}
                    {file.status.toUpperCase()}
                  </span>
                </div>

                <div className="space-y-1">
                  <h4 className="text-sm font-semibold text-slate-100 group-hover:text-indigo-400 transition-colors block truncate">
                    {file.name}
                  </h4>
                  <p className="text-[10px] text-slate-500 font-mono">
                    {(file.size / 1024).toFixed(1)} KB // Sourced: {file.uploadedAt}
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="pt-3 border-t border-white/5 flex items-center justify-between text-xs">
                <button
                  onClick={() => onSelectFile(file)}
                  className="text-indigo-400 hover:text-indigo-300 font-semibold inline-flex items-center gap-1 transition-colors"
                >
                  <Eye className="w-3.5 h-3.5" />
                  Inspect Analysis
                </button>

                <button
                  onClick={() => onDeleteFile(file.id)}
                  className="text-slate-500 hover:text-red-400 p-1 rounded transition-colors"
                  title="Remove isolate from vault"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        // List view
        <div className="bg-[#131826]/40 rounded-2xl border border-white/5 overflow-hidden">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-white/5 text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest p-4 inline-table w-full">
                <th className="w-1/3">File Name</th>
                <th className="w-1/6">Assay Class</th>
                <th className="w-1/6">Sourced Date</th>
                <th className="w-1/6">Status</th>
                <th className="w-1/6 text-right">Vault action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-xs text-slate-300 block max-h-[400px] overflow-y-auto">
              {filteredFiles.map((file) => (
                <tr key={file.id} className="hover:bg-white/[0.01] transition-colors p-4 inline-table w-full">
                  <td className="w-1/3 font-semibold text-slate-200 truncate pr-4">{file.name}</td>
                  <td className="w-1/6">
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-bold font-mono bg-indigo-500/10 text-indigo-300">
                      {file.type.toUpperCase()}
                    </span>
                  </td>
                  <td className="w-1/6 text-slate-500 font-mono">{file.uploadedAt}</td>
                  <td className="w-1/6">
                    <span className={`inline-flex items-center gap-1 text-[10px] font-mono font-bold ${
                      file.status === "analyzed" ? "text-emerald-400" : "text-amber-400"
                    }`}>
                      {file.status === "analyzed" ? "Analyzed" : "Processing"}
                    </span>
                  </td>
                  <td className="w-1/6 text-right space-x-2">
                    <button
                      onClick={() => onSelectFile(file)}
                      className="px-2 py-1 bg-white/5 hover:bg-white/10 rounded font-semibold text-[10px] text-indigo-400 transition-all inline-flex items-center gap-1"
                    >
                      <Eye className="w-3 h-3" /> Inspect
                    </button>
                    <button
                      onClick={() => onDeleteFile(file.id)}
                      className="p-1 text-slate-500 hover:text-red-400 rounded inline-block transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

    </div>
  );
}
