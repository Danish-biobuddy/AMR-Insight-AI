import React, { useState } from "react";
import { 
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip, Legend, ResponsiveContainer, Cell, AreaChart, Area 
} from "recharts";
import { SlidersHorizontal, Info, TrendingUp, AlertTriangle, Globe, FlaskConical } from "lucide-react";
import { TRENDS_TIME_SERIES, GENE_FREQUENCY_DISTRIBUTION } from "../initialData";

export default function TrendsWorkspace() {
  const [organismFilter, setOrganismFilter] = useState("all");
  const [sourceFilter, setSourceFilter] = useState("all");
  const [temporalRange, setTemporalRange] = useState("all");

  return (
    <div id="trends-workspace-container" className="space-y-8">
      
      {/* Top filter dashboard banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-2xl bg-[#131826]/40 border border-white/5">
        <div className="space-y-1">
          <h2 className="text-base font-semibold font-display text-white flex items-center gap-2">
            <Globe className="w-5 h-5 text-indigo-400" />
            One Health Global Resistance Surveillance
          </h2>
          <p className="text-xs text-slate-500">Epidemiological aggregates intersecting environmental and clinical sectors</p>
        </div>

        {/* Filters Selectors */}
        <div className="flex flex-wrap gap-3">
          {/* Organism select */}
          <div className="space-y-0.5">
            <span className="text-[9px] font-mono font-bold text-slate-500 uppercase block">Organism</span>
            <select
              value={organismFilter}
              onChange={(e) => setOrganismFilter(e.target.value)}
              className="px-2 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-[11px] text-slate-300 outline-none focus:border-indigo-500/50"
            >
              <option value="all">All Enteric Isolates</option>
              <option value="kp">Klebsiella pneumoniae</option>
              <option value="ec">Escherichia coli</option>
              <option value="ab">Acinetobacter baumannii</option>
            </select>
          </div>

          {/* Sources select */}
          <div className="space-y-0.5">
            <span className="text-[9px] font-mono font-bold text-slate-500 uppercase block">Sample Source</span>
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="px-2 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-[11px] text-slate-300 outline-none focus:border-indigo-500/50"
            >
              <option value="all">All Sectors integrated</option>
              <option value="human">Clinical: Human ICU wards</option>
              <option value="env">Environmental: Wastewater canals</option>
              <option value="agri">Agribusiness: Livestock runoff</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Charts double grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* Chart A: Line Chart Trends over time */}
        <div className="p-6 rounded-2xl bg-[#131826]/60 border border-white/5 space-y-6">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-white">Resistance prevalence over time (2020 - 2026)</h3>
              <p className="text-[11px] text-slate-500">Percentage of isolates displaying clinical non-susceptibility</p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-mono font-bold bg-emerald-500/5 px-2 py-0.5 rounded border border-emerald-500/10">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>COLISTIN ESCAPE ++</span>
            </div>
          </div>

          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={TRENDS_TIME_SERIES} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" />
                <XAxis dataKey="year" tick={{ fill: "#94A3B8", fontSize: "11px" }} />
                <YAxis tick={{ fill: "#94A3B8", fontSize: "11px" }} suffix="%" />
                <Tooltip 
                  contentStyle={{ background: "#0F172A", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px" }}
                  labelStyle={{ color: "#fff", fontSize: "11px" }}
                  itemStyle={{ fontSize: "11px" }}
                />
                <Legend iconType="circle" wrapperStyle={{ fontSize: "11px", paddingTop: "10px" }} />
                
                <Line type="monotone" dataKey="MRSA" stroke="#818CF8" strokeWidth={3} name="MRSA (Staphylococcus)" activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="CarbapenemResistantKleb" stroke="#FBBF24" strokeWidth={3} name="Carbapenem-Resistant Klebsiella" />
                <Line type="monotone" dataKey="ColistinResistant" stroke="#F87171" strokeWidth={3.5} strokeDasharray="5 5" name="Colistin escaping Enterobacteriaceae" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart B: Bar Chart Gene Frequency Distribution */}
        <div className="p-6 rounded-2xl bg-[#131826]/60 border border-white/5 space-y-6">
          <div className="flex justify-between items-start">
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-white">Global Gene Marker abundances</h3>
              <p className="text-[11px] text-slate-500">Frequency distribution retrieved from unified surveillance registers</p>
            </div>
            <span className="text-[10px] font-mono text-slate-500 font-bold uppercase">NCBI Registry Linked</span>
          </div>

          <div className="h-[280px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={GENE_FREQUENCY_DISTRIBUTION} margin={{ top: 10, right: 10, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.03)" />
                <XAxis dataKey="name" tick={{ fill: "#94A3B8", fontSize: "10px" }} />
                <YAxis tick={{ fill: "#94A3B8", fontSize: "10px" }} />
                <Tooltip 
                  cursor={{ fill: "rgba(255,255,255,0.02)" }}
                  contentStyle={{ background: "#0F172A", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px" }}
                  labelStyle={{ color: "#fff", fontSize: "11px" }}
                  itemStyle={{ fontSize: "11px" }}
                />
                <Bar dataKey="frequency" fill="#22D3EE" radius={[4, 4, 0, 0]}>
                  {GENE_FREQUENCY_DISTRIBUTION.map((entry, index) => (
                    <Cell 
                      key={`bar-${index}`} 
                      fill={entry.name.includes("bla") ? "url(#indigoCyanGrad)" : "#F87171"} 
                    />
                  ))}
                </Bar>
                
                {/* SVG gradient definition */}
                <defs>
                  <linearGradient id="indigoCyanGrad" x1="0%" y1="100%" x2="0%" y2="0%">
                    <stop offset="0%" stopColor="#6366F1" />
                    <stop offset="100%" stopColor="#22D3EE" />
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Epidemic Surveillance Alert details card */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-red-500/5 to-amber-500/5 border border-red-500/10 flex flex-col sm:flex-row sm:items-center gap-4 text-xs">
        <AlertTriangle className="w-6 h-6 text-red-400 shrink-0 select-none animate-pulse" />
        <div className="space-y-1 font-sans">
          <span className="font-bold text-red-200 block uppercase tracking-wider font-mono text-[11px]">Warning: Persistent Colistin Escape Vectors Rising</span>
          <p className="text-slate-400 font-normal leading-relaxed text-[11.5px]">
            Wastewater registers indicate an 8% rise in colistin-resistant transconjugants in suburban waterways. These profiles exhibit plasmid-hosted **mcr-9** and **mcr-1** loci or non-silent truncation mutations in host **mgrB** loops. Extreme vigilance in hospital sanitation is recommended.
          </p>
        </div>
      </div>
    </div>
  );
}
