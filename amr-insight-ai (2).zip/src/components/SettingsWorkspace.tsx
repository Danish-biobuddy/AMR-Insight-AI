import React, { useState } from "react";
import { Key, Moon, Sun, ShieldCheck, Database, RefreshCw, Trash2, Eye, EyeOff } from "lucide-react";

interface SettingsWorkspaceProps {
  apiKey: string;
  onUpdateApiKey: (key: string) => void;
  onClearSession: () => void;
  theme: "dark" | "light";
  onToggleTheme: () => void;
}

export default function SettingsWorkspace({ apiKey, onUpdateApiKey, onClearSession, theme, onToggleTheme }: SettingsWorkspaceProps) {
  const [showKey, setShowKey] = useState(false);
  const [localKey, setLocalKey] = useState(apiKey);
  const [isSaved, setIsSaved] = useState(false);

  const handleSaveKey = () => {
    onUpdateApiKey(localKey);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  return (
    <div id="settings-workspace-wrapper" className="max-w-3xl mx-auto space-y-8">
      
      <div>
        <h2 className="text-xl font-display font-medium text-white tracking-tight">System Preferences</h2>
        <p className="text-xs text-slate-400">Configure private sandbox integrations and theme variables</p>
      </div>

      {/* 1. Gemini Key Controller */}
      <div className="p-6 rounded-2xl bg-[#131826]/60 border border-white/5 space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-500/10 text-indigo-400 rounded-lg">
            <Key className="w-4.5 h-4.5" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">Gemini API Configuration</h3>
            <p className="text-[10.5px] text-slate-500">Provided securely via platform secret bindings</p>
          </div>
        </div>

        <div className="space-y-3 pt-2">
          <div className="text-xs text-slate-400 leading-relaxed font-sans bg-indigo-500/5 p-3.5 rounded-xl border border-indigo-500/10 mb-2">
            The platform automatically injects your **GEMINI_API_KEY** directly from the **Settings &gt; Secrets** panel in the workspace UI. You can also override it below for this active local session.
          </div>

          <div className="flex gap-2">
            <div className="relative flex-1">
              <input
                type={showKey ? "text" : "password"}
                value={localKey}
                onChange={(e) => setLocalKey(e.target.value)}
                placeholder="Using preconfigured runtime secret..."
                className="w-full pl-3 pr-10 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-200 outline-none focus:border-indigo-500/40 font-mono tracking-tight"
              />
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="absolute right-3 top-3 text-slate-500 hover:text-slate-300"
              >
                {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            
            <button
              onClick={handleSaveKey}
              className="px-4 py-2.5 bg-indigo-650 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold transition-all cursor-pointer"
            >
              {isSaved ? "Loaded" : "Override"}
            </button>
          </div>
        </div>
      </div>

      {/* 2. Visual Theme Toggle */}
      <div className="p-6 rounded-2xl bg-[#131826]/60 border border-white/5 space-y-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-cyan-500/10 text-cyan-400 rounded-lg">
              {theme === "dark" ? <Moon className="w-4.5 h-4.5" /> : <Sun className="w-4.5 h-4.5" />}
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Visual Dressing</h3>
              <p className="text-[10.5px] text-slate-500">Set visual tone for laboratory screens</p>
            </div>
          </div>

          <button 
            onClick={onToggleTheme}
            className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs font-semibold text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            Switch to {theme === "dark" ? "Light Mode" : "Dark Mode"}
          </button>
        </div>
      </div>

      {/* 3. Session Clearing, purging */}
      <div className="p-6 rounded-2xl bg-[#131826]/60 border border-white/5 space-y-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 text-amber-400 rounded-lg">
              <Database className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white">Isolate Memory Purge</h3>
              <p className="text-[10.5px] text-slate-500">Purge loaded assemblies, reports, and timeline registers</p>
            </div>
          </div>

          <button
            onClick={() => {
              if (confirm("Are you sure you want to restore workspace memory? This clears uploaded isolates.")) {
                onClearSession();
              }
            }}
            className="px-4 py-2 bg-red-500/10 hover:bg-red-500/25 text-red-400 rounded-xl text-xs font-bold transition-all border border-red-500/15 cursor-pointer flex items-center gap-1.5"
          >
            <Trash2 className="w-4 h-4" />
            Purge Memory
          </button>
        </div>
      </div>

      {/* 4. Information card */}
      <div className="p-5 rounded-2xl bg-[#131826]/20 border border-white/5 text-center text-[10.5px] font-mono text-slate-500 flex items-center justify-between">
        <span className="flex items-center gap-1.5 leading-none">
          <ShieldCheck className="w-4.5 h-4.5 text-emerald-400" />
          BIOSAFETY INTEL REGULATION COMPLIANT // SECURE PREVIEW SHELL
        </span>
        <span>BUILD VER // 3.5.15-PR</span>
      </div>

    </div>
  );
}
