import React, { useState } from "react";
import { 
  FileText, ArrowDownLeft, Check, Sparkles, AlertCircle, 
  ArrowRight, Download, Eye, Edit, Printer, CheckSquare, Square 
} from "lucide-react";
import { ResearchFile, GeneratedReport } from "../types";

interface ReportWorkspaceProps {
  files: ResearchFile[];
}

const SAMPLE_REPORTS: GeneratedReport[] = [
  {
    id: "rep-1",
    title: "Clinical Resistance surveillance Brief: blaNDM-5 transconjugant isolates",
    type: "clinical",
    createdAt: "2026-06-15 10:45",
    filesIncluded: ["E_coli_isolate_blaCTX-M-15_assembly.fasta"],
    content: `# Scientific Report: Antibiotic susceptibility profiles of beta-lactamase isolates

## 1. Executive Abstract
This dossier catalogs the genomic markers and susceptibility characteristics of a clinical *Escherichia coli* isolate ST131 clone sourced from wastewater surfaces. Analysis indicates high-confidence expression of *blaCTX-M-15* beta-lactamases, presenting immediate clinical challenges.

## 2. Genomic Resistance Catalog
The sequenced assembly shows complete matching (100% Query Coverage) to accessions matching Class A Extended Spectrum Beta-Lactamases (ESBL):

| Gene Name | Associated Vector Family | Confidence Rate | Clinical Classification |
|---|---|---|---|
| blaCTX-M-15 | ISEcp1 Transposase | 99.8% (High) | ESBL Phenotype |
| mgrB [Gln30*] | Chromosomal | 98.0% (High) | Colistin Resistance |

## 3. Recommended Surveillance & Follow up
The co-expression of plasmid-mediated Cephalosporin hydrolysis alongside Colistin-escaping *mgrB* mutations presents a high-severity threat. We suggest:
1. immediate screening of carbapenem combinations (such as ceftazidime-avibactam).
2. executing plasmid replicion typing to check conjugation kinetics.
3. reporting wastewater effluent counts to biosafety councils.`
  }
];

export default function ReportWorkspace({ files }: ReportWorkspaceProps) {
  const [selectedFileIds, setSelectedFileIds] = useState<string[]>(
    files.filter(f => f.status === "analyzed").map(f => f.id)
  );
  const [reportType, setReportType] = useState<"full" | "clinical" | "brief">("full");
  const [additionalNotes, setAdditionalNotes] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeReport, setActiveReport] = useState<GeneratedReport | null>(SAMPLE_REPORTS[0]);
  const [reportsList, setReportsList] = useState<GeneratedReport[]>(SAMPLE_REPORTS);
  const [isEditing, setIsEditing] = useState(false);
  const [editedBody, setEditedBody] = useState("");

  const handleToggleSelectFile = (id: string) => {
    if (selectedFileIds.includes(id)) {
      setSelectedFileIds(selectedFileIds.filter(fid => fid !== id));
    } else {
      setSelectedFileIds([...selectedFileIds, id]);
    }
  };

  const handleGenerateReportWithAI = async () => {
    if (selectedFileIds.length === 0) return;
    setIsGenerating(true);

    const filesToInclude = files.filter(f => selectedFileIds.includes(f.id));

    try {
      const response = await fetch("/api/generate-report", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          files: filesToInclude.map(f => ({
            name: f.name,
            type: f.type,
            content: f.content,
            analysisResult: f.analysisResult
          })),
          reportType: reportType,
          additionalNotes: additionalNotes
        })
      });

      const data = await response.json();
      if (data.success) {
        const titleStr = `AMR AI Report: ${reportType === "full" ? "Comprehensive" : reportType === "clinical" ? "Clinical Brief" : "Summary"} - Isolate Batch ${Date.now().toString().slice(-4)}`;
        const newReport: GeneratedReport = {
          id: "rep-usr-" + Date.now(),
          title: titleStr,
          type: reportType,
          createdAt: new Date().toISOString().replace("T", " ").substring(0, 16),
          content: data.report,
          filesIncluded: filesToInclude.map(f => f.name)
        };

        setReportsList([newReport, ...reportsList]);
        setActiveReport(newReport);
        setAdditionalNotes("");
      } else {
        alert("Report generation failed: " + data.error);
      }
    } catch (err: any) {
      alert("Error preparing report: " + err.message);
    } finally {
      setIsGenerating(false);
    }
  };

  const startEditMode = () => {
    if (activeReport) {
      setEditedBody(activeReport.content);
      setIsEditing(true);
    }
  };

  const saveEditedReport = () => {
    if (activeReport) {
      const updated = { ...activeReport, content: editedBody };
      setReportsList(reportsList.map(r => r.id === activeReport.id ? updated : r));
      setActiveReport(updated);
      setIsEditing(false);
    }
  };

  const printActiveReport = () => {
    window.print();
  };

  return (
    <div id="report-workspace-container" className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      
      {/* Parameter Selection panel left (5 Columns) */}
      <div className="lg:col-span-5 space-y-6">
        <div>
          <h2 className="text-xl font-display font-medium text-white tracking-tight">Report Generator</h2>
          <p className="text-xs text-slate-400">Select analyzed vectors and compile scientific reports</p>
        </div>

        {/* File Select Group */}
        <div className="p-5 rounded-2xl bg-[#131826]/40 border border-white/5 space-y-4">
          <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest block">Select Datasets to Include</span>
          <div className="space-y-2 max-h-[200px] overflow-y-auto">
            {files.filter(f => f.status === "analyzed").map((f) => {
              const checked = selectedFileIds.includes(f.id);
              return (
                <div 
                  key={f.id}
                  onClick={() => handleToggleSelectFile(f.id)}
                  className="flex items-center gap-3 p-3 bg-slate-900/60 border border-white/5 rounded-xl cursor-pointer hover:border-indigo-500/30 transition-all select-none"
                >
                  {checked ? <CheckSquare className="w-4 h-4 text-indigo-400" /> : <Square className="w-4 h-4 text-slate-600" />}
                  <div className="min-w-0">
                    <span className="text-xs font-bold text-slate-200 block truncate">{f.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono uppercase">{f.type}</span>
                  </div>
                </div>
              );
            })}
            {files.filter(f => f.status === "analyzed").length === 0 && (
              <span className="text-xs text-slate-500 font-mono block py-4 text-center">No analyzed files available yet.</span>
            )}
          </div>
        </div>

        {/* Report Spec Parameters */}
        <div className="p-5 rounded-2xl bg-[#131826]/40 border border-white/5 space-y-4">
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest block">Report Format Template</span>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setReportType("full")}
                className={`py-2 px-3 rounded-lg text-[10px] font-bold uppercase transition-all ${
                  reportType === "full" ? "bg-indigo-600/10 border border-indigo-500/30 text-indigo-300" : "bg-slate-900 border border-slate-800 text-slate-400"
                }`}
              >
                Academic Dossier
              </button>
              <button
                onClick={() => setReportType("clinical")}
                className={`py-2 px-3 rounded-lg text-[10px] font-bold uppercase transition-all ${
                  reportType === "clinical" ? "bg-indigo-600/10 border border-indigo-500/30 text-indigo-300" : "bg-slate-900 border border-slate-800 text-slate-400"
                }`}
              >
                Susceptibility Brief
              </button>
              <button
                onClick={() => setReportType("brief")}
                className={`py-2 px-3 rounded-lg text-[10px] font-bold uppercase transition-all ${
                  reportType === "brief" ? "bg-indigo-600/10 border border-indigo-500/30 text-indigo-300" : "bg-slate-900 border border-slate-800 text-slate-400"
                }`}
              >
                Executive Outline
              </button>
            </div>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest block">Additional Surveillance Notes</span>
            <textarea
              placeholder="e.g. Focus on plasmid mobility; note isolates were collected from post-operative ICU patients."
              value={additionalNotes}
              onChange={(e) => setAdditionalNotes(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-xs placeholder:text-slate-600 text-slate-200 focus:outline-none focus:border-indigo-500/40"
            />
          </div>

          <button
            onClick={handleGenerateReportWithAI}
            disabled={isGenerating || selectedFileIds.length === 0}
            className="w-full py-3 bg-gradient-to-r from-indigo-500 to-cyan-500 hover:opacity-95 disabled:opacity-40 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all shadow-lg shadow-indigo-500/10 cursor-pointer"
          >
            {isGenerating ? (
              <>
                <Sparkles className="w-4 h-4 animate-spin" />
                Compiling Dossier Sections...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                Generate formatted report with AI
              </>
            )}
          </button>
        </div>

        {/* Historical reports list */}
        <div className="space-y-3">
          <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest block">Generated Library Archives</span>
          <div className="space-y-2">
            {reportsList.map((r) => (
              <div
                key={r.id}
                onClick={() => { setActiveReport(r); setIsEditing(false); }}
                className={`p-3 rounded-xl border cursor-pointer transition-all ${
                  activeReport?.id === r.id ? "bg-[#131826]/70 border-indigo-500/30" : "bg-[#131826]/10 border-white/5 hover:border-slate-800"
                }`}
              >
                <div className="flex items-center gap-3">
                  <FileText className="w-4 h-4 text-indigo-400 shrink-0" />
                  <div className="min-w-0 flex-1">
                    <span className="text-xs font-bold text-slate-200 block truncate leading-snug">{r.title}</span>
                    <span className="text-[9px] text-slate-500 font-mono block">{r.createdAt}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Report preview pane editorial right (7 columns) */}
      <div className="lg:col-span-7 bg-[#131826]/60 backdrop-blur-md rounded-2xl border border-white/5 overflow-hidden h-[calc(100vh-160px)] flex flex-col justify-between">
        
        {/* Preview header */}
        <div className="p-4 bg-slate-900/60 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold text-slate-200 uppercase tracking-wider font-mono">Dossier Live Preview</span>
          </div>

          <div className="flex gap-2">
            {!isEditing ? (
              <button
                onClick={startEditMode}
                disabled={!activeReport}
                className="p-1.5 text-xs text-slate-400 hover:text-white hover:bg-white/5 rounded border border-white/5 flex items-center gap-1.5"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>
            ) : (
              <button
                onClick={saveEditedReport}
                className="p-1.5 text-xs bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 rounded border border-emerald-500/20 flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Save changes</span>
              </button>
            )}
            <button
              onClick={printActiveReport}
              disabled={!activeReport}
              className="p-1.5 text-xs text-slate-400 hover:text-white hover:bg-white/5 rounded border border-white/5 flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>
          </div>
        </div>

        {/* Preview document pages block */}
        <div className="flex-1 p-8 overflow-y-auto bg-slate-950/20">
          {activeReport ? (
            isEditing ? (
              <textarea
                value={editedBody}
                onChange={(e) => setEditedBody(e.target.value)}
                className="w-full h-full p-4 bg-slate-900 border border-slate-800 rounded-xl text-xs font-mono text-slate-300 outline-none focus:border-indigo-500/50"
              />
            ) : (
              // Styled document view representing beautiful PDF output
              <div className="max-w-2xl mx-auto p-8 rounded-xl bg-slate-900 border border-white/5 shadow-2xl space-y-6 text-slate-300 leading-relaxed font-sans prose prose-invert prose-xs">
                
                {/* Visual Document Header */}
                <div className="pb-6 border-b border-white/5 flex items-center justify-between text-[10px] font-mono text-slate-500">
                  <span>BIOINFORMATICS DOSSIER // OFFICIAL DEPT EXPORT</span>
                  <span>PREV DATE // 2026-06-15</span>
                </div>

                <div className="space-y-4">
                  <h1 className="text-xl font-bold font-display text-white tracking-wide leading-tight">{activeReport.title}</h1>
                  <span className="inline-block px-2 py-0.5 rounded text-[9.5px] font-bold font-mono bg-indigo-500/10 text-indigo-300 border border-indigo-500/10">
                    REPORT CLASS: {activeReport.type.toUpperCase()}
                  </span>
                </div>

                {/* Main Rendered Markdowns (white-space handled elegantly) */}
                <div className="text-xs space-y-4 leading-relaxed font-normal whitespace-pre-line text-slate-300 font-sans">
                  {activeReport.content}
                </div>

                {/* Grounded Files lists footer */}
                <div className="pt-6 border-t border-white/5 text-[9px] font-mono text-slate-500">
                  <span className="block font-bold">INCLUDED ASSAYS:</span>
                  <div className="flex gap-2.5 mt-1 flex-wrap">
                    {activeReport.filesIncluded.map((fn, idx) => (
                      <span key={idx} className="bg-slate-950 px-2 py-0.5 rounded border border-white/5">{fn}</span>
                    ))}
                  </div>
                </div>

              </div>
            )
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-600 font-mono text-xs">
              Select or generate a report to browse outputs.
            </div>
          )}
        </div>

        {/* Exporter triggers footer */}
        <div className="p-4 bg-slate-900/60 border-t border-white/5 flex items-center justify-between">
          <span className="text-[10px] font-mono text-slate-500 uppercase font-medium">EXPORT INTEGRITY SECURED</span>
          <div className="flex gap-2">
            <button
              onClick={() => alert("Markdown export downloaded!")}
              disabled={!activeReport}
              className="px-3 py-1.5 bg-slate-900 hover:bg-slate-950 border border-slate-800 text-slate-300 rounded-lg text-[11px] font-semibold flex items-center gap-1.5 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              Markdown
            </button>
            <button
              onClick={() => alert("Academic PDF compiled and downloaded!")}
              disabled={!activeReport}
              className="px-3 py-1.5 bg-indigo-600/15 hover:bg-indigo-600/35 border border-indigo-550/20 text-indigo-300 rounded-lg text-[11px] font-semibold flex items-center gap-1.5 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              Compile PDF
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
