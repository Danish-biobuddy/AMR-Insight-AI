import React from "react";
import { Terminal, Shield, FileText, Activity, Dna, ArrowRight, Database, ChevronRight, Share2, Sparkles, AlertCircle } from "lucide-react";

interface LandingPageProps {
  onLaunch: () => void;
}

export default function LandingPage({ onLaunch }: LandingPageProps) {
  return (
    <div id="landing-container" className="min-h-screen bg-[#0B0F19] text-slate-100 overflow-x-hidden relative">
      {/* Background radial gradient mesh blobs */}
      <div id="bg-mesh-1" className="absolute top-1/4 left-1/4 -translate-y-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-indigo-500/10 rounded-full blur-[120px] pointer-events-none"></div>
      <div id="bg-mesh-2" className="absolute bottom-1/4 right-1/4 translate-y-1/2 translate-x-1/2 w-[400px] h-[400px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none"></div>

      {/* Navigation Layer */}
      <nav id="landing-nav" className="max-w-7xl mx-auto px-6 py-6 flex items-center justify-between border-b border-white/5 relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Dna className="w-6 h-6 text-slate-900 stroke-[2.5]" />
          </div>
          <div>
            <span className="font-display font-bold text-lg tracking-wider bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">AMR INSIGHT</span>
            <span className="ml-1.5 px-1.5 py-0.5 text-[9px] font-mono font-bold bg-indigo-500/20 text-cyan-400 rounded-md tracking-wider border border-indigo-500/30">AI PLATFORM</span>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <a href="#features" className="text-sm font-medium text-slate-400 hover:text-white transition-colors">Capabilities</a>
          <a href="#how-it-works" className="text-sm font-medium text-slate-400 hover:text-white transition-colors">Methodology</a>
          <button 
            onClick={onLaunch}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-all hover:shadow-lg hover:shadow-indigo-500/20"
          >
            Sign In
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="hero-section" className="max-w-7xl mx-auto px-6 pt-16 pb-24 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
        <div className="lg:col-span-7 space-y-8">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-indigo-300 text-xs font-medium">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Multi-modal Genomic Intelligence Engine</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold tracking-tight text-white leading-[1.1]">
            Decode Antimicrobial <br />
            <span className="bg-gradient-to-r from-indigo-400 via-cyan-400 to-emerald-400 bg-clip-text text-transparent">
              Resistance with AI
            </span>
          </h1>

          <p className="text-base sm:text-lg text-slate-400 max-w-xl leading-relaxed font-normal">
            Explain resistance genes, track mutations, interpret AST phenotypes, and compile literature summaries in seconds. Integrated with state-of-the-art Gemini intelligence for clinical, diagnostic, and academic surveillance.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={onLaunch}
              className="px-8 py-4 bg-gradient-to-r from-indigo-500 to-cyan-500 hover:opacity-95 text-slate-900 font-semibold rounded-xl text-sm flex items-center justify-center gap-2 transition-all transform hover:-translate-y-0.5 active:translate-y-0 shadow-lg shadow-indigo-500/25 cursor-pointer"
            >
              Launch Researcher Workspace
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>
            <a
              href="#features"
              className="px-8 py-4 bg-slate-900/60 hover:bg-slate-950 hover:text-white border border-slate-800 text-slate-300 font-medium rounded-xl text-sm flex items-center justify-center transition-all"
            >
              Explore Capabilities
            </a>
          </div>

          <div className="pt-8 border-t border-white/5 grid grid-cols-3 gap-6">
            <div>
              <div className="text-2xl font-bold font-display text-white">99.8%</div>
              <div className="text-xs text-slate-500 font-medium">Genomic Matching Accuracy</div>
            </div>
            <div>
              <div className="text-2xl font-bold font-display text-white">&lt; 3.2s</div>
              <div className="text-xs text-slate-500 font-medium">Gemini Real-time Synthesis</div>
            </div>
            <div>
              <div className="text-2xl font-bold font-display text-white">20k+</div>
              <div className="text-xs text-slate-500 font-medium">AMR Markers Monitored</div>
            </div>
          </div>
        </div>

        {/* Decorative Interactive DNA / Network SVG illustration */}
        <div className="lg:col-span-5 relative flex justify-center">
          <div className="relative w-full max-w-[420px] aspect-square rounded-3xl bg-slate-900/40 border border-slate-800/80 p-8 flex items-center justify-center shadow-2xl overflow-hidden glass-panel">
            <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/5 to-cyan-500/5 pointer-events-none"></div>
            
            {/* Network Graph Animation Simulation */}
            <svg viewBox="0 0 400 400" className="w-full h-full opacity-80">
              <defs>
                <linearGradient id="primaryGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#6366F1" />
                  <stop offset="100%" stopColor="#22D3EE" />
                </linearGradient>
              </defs>
              
              {/* Connecting connection lines */}
              <g stroke="rgba(255,255,255,0.06)" strokeWidth="1px">
                <line x1="80" y1="80" x2="200" y2="100" />
                <line x1="200" y1="100" x2="320" y2="100" />
                <line x1="120" y1="220" x2="200" y2="100" />
                <line x1="120" y1="220" x2="280" y2="280" />
                <line x1="280" y1="280" x2="320" y2="100" />
                <line x1="200" y1="100" x2="200" y2="340" />
                <line x1="120" y1="220" x2="200" y2="340" />
                <line x1="280" y1="280" x2="200" y2="340" />
              </g>

              {/* Pulsing highlights */}
              <circle cx="200" cy="100" r="14" fill="rgba(99,102,241,0.15)" />
              <circle cx="120" cy="220" r="14" fill="rgba(34,211,238,0.15)" />
              <circle cx="280" cy="280" r="14" fill="rgba(52,211,153,0.15)" />

              {/* Core Nodes */}
              <circle cx="80" cy="80" r="6" fill="#6366F1" />
              <circle cx="200" cy="100" r="8" fill="url(#primaryGrad)" />
              <circle cx="320" cy="100" r="5" fill="#22D3EE" />
              <circle cx="120" cy="220" r="7" fill="#22D3EE" />
              <circle cx="280" cy="280" r="9" fill="#34D399" />
              <circle cx="200" cy="340" r="6" fill="#FBBF24" />

              {/* DNA Helix Representation Curve Overlay */}
              <path 
                d="M 50 150 Q 120 70 200 150 T 350 150" 
                fill="none" 
                stroke="url(#primaryGrad)" 
                strokeWidth="2.5" 
                strokeDasharray="6,4"
                className="opacity-60"
              />
              <path 
                d="M 50 150 Q 120 230 200 150 T 350 150" 
                fill="none" 
                stroke="#34D399" 
                strokeWidth="1.5" 
                strokeDasharray="4,4"
                className="opacity-40"
              />

              {/* Text labels resembling bioinformatics tags */}
              <text x="215" y="95" className="text-[10px] font-mono fill-indigo-300 font-bold">blaCTX-M-15</text>
              <text x="50" y="235" className="text-[10px] font-mono fill-cyan-300 font-bold">mgrB [Gln30*]</text>
              <text x="295" y="285" className="text-[10px] font-mono fill-emerald-300 font-bold">OXA-23</text>
            </svg>

            {/* Simulated Live Diagnostic Readout Card floating */}
            <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-slate-950/95 border border-white/10 flex items-center justify-between shadow-2xl">
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></div>
                <div>
                  <div className="text-[11px] font-mono font-bold text-slate-300">SYSTEM STABLE // NO LOCAL ACCIDENTS</div>
                  <div className="text-[9px] font-mono text-slate-500">Listening to CARD ontology databases</div>
                </div>
              </div>
              <Terminal className="w-4 h-4 text-slate-500" />
            </div>
          </div>
        </div>
      </section>

      {/* Feature Grid Section */}
      <section id="features" className="max-w-7xl mx-auto px-6 py-24 border-t border-white/5 relative z-10">
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <h2 className="text-3xl font-display font-semibold tracking-tight text-white sm:text-4xl">
            Targeted AI Bioinformatics Modules
          </h2>
          <p className="text-slate-400 text-sm">
            Harness tailored pipeline prompts mapped to specific scientific payloads.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Feature 1 */}
          <div className="p-6 rounded-2xl bg-slate-900/30 border border-white/5 hover:border-indigo-500/30 hover:bg-slate-900/50 transition-all duration-300 group hover:-translate-y-1">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center mb-6 border border-indigo-500/25 group-hover:bg-indigo-600 group-hover:text-slate-900 transition-all text-indigo-400">
              <Dna className="w-5 h-5 text-indigo-400 group-hover:text-slate-900" />
            </div>
            <h3 className="text-lg font-semibold font-display text-white mb-2">FASTA Sequence Assembly</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Identify open reading frames, parse homology highlights, and verify confidence percentages against established AMR determinants.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="p-6 rounded-2xl bg-slate-900/30 border border-white/5 hover:border-cyan-500/30 hover:bg-slate-900/50 transition-all duration-300 group hover:-translate-y-1">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center mb-6 border border-cyan-500/25 group-hover:bg-cyan-600 group-hover:text-slate-900 transition-all text-cyan-400">
              <Activity className="w-5 h-5 text-cyan-400 group-hover:text-slate-900" />
            </div>
            <h3 className="text-lg font-semibold font-display text-white mb-2">VCF Variant & SNP Grading</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Grade mutation impact (such as gyrA missense codons or mgrB nonsense truncations) with an interactive 0-100 severity meter and structural analysis.
            </p>
          </div>

          {/* Feature 3 */}
          <div className="p-6 rounded-2xl bg-slate-900/30 border border-white/5 hover:border-emerald-500/30 hover:bg-slate-900/50 transition-all duration-300 group hover:-translate-y-1">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center mb-6 border border-emerald-500/25 group-hover:bg-emerald-600 group-hover:text-slate-900 transition-all text-emerald-400">
              <FileText className="w-5 h-5 text-emerald-400 group-hover:text-slate-900" />
            </div>
            <h3 className="text-lg font-semibold font-display text-white mb-2">Literature Evidence Mining</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Extract gene targets and susceptibility stats from PDF papers with an elegant highlight-and-ask side panel for real-time validation questions.
            </p>
          </div>

          {/* Feature 4 */}
          <div className="p-6 rounded-2xl bg-slate-900/30 border border-white/5 hover:border-amber-500/30 hover:bg-slate-900/50 transition-all duration-300 group hover:-translate-y-1">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center mb-6 border border-amber-500/25 group-hover:bg-amber-600 group-hover:text-slate-900 transition-all text-amber-400">
              <Database className="w-5 h-5 text-amber-400 group-hover:text-slate-900" />
            </div>
            <h3 className="text-lg font-semibold font-display text-white mb-2">AST Phenotype Interpretation</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Map disk diffusion lists, MIC titers, and custom laboratory panels automatically into standard clinical susceptibility profiles (SIR).
            </p>
          </div>

          {/* Feature 5 */}
          <div className="p-6 rounded-2xl bg-slate-900/30 border border-white/5 hover:border-purple-500/30 hover:bg-slate-900/50 transition-all duration-300 group hover:-translate-y-1">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center mb-6 border border-purple-500/25 group-hover:bg-purple-600 group-hover:text-slate-900 transition-all text-purple-400">
              <Terminal className="w-5 h-5 text-purple-400 group-hover:text-slate-900" />
            </div>
            <h3 className="text-lg font-semibold font-display text-white mb-2">Gene List Accordions</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Verify multiple pathways simultaneously. Select multiple distinct genes side-by-side to review synergy mechanisms, like beta-lactamase + outer membrane efflux.
            </p>
          </div>

          {/* Feature 6 */}
          <div className="p-6 rounded-2xl bg-slate-900/30 border border-white/5 hover:border-rose-500/30 hover:bg-slate-900/50 transition-all duration-300 group hover:-translate-y-1">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 flex items-center justify-center mb-6 border border-rose-500/25 group-hover:bg-rose-600 group-hover:text-slate-900 transition-all text-rose-400">
              <Shield className="w-5 h-5 text-rose-400 group-hover:text-slate-900" />
            </div>
            <h3 className="text-lg font-semibold font-display text-white mb-2">Protein Structure Hotspots</h3>
            <p className="text-slate-400 text-xs leading-relaxed">
              Zoom and examine fold models of beta-lactamase or ribosomes. Identify codon regions that lead to steric hindrance or altered drug-binding configurations.
            </p>
          </div>
        </div>
      </section>

      {/* How it Works Stepflow Section */}
      <section id="how-it-works" className="max-w-7xl mx-auto px-6 py-20 border-t border-white/5 relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-2xl font-display font-semibold text-white">Advanced Laboratory Workflow</h2>
          <p className="text-xs text-slate-500 mt-2 font-mono">3-STEP INSIGHT RETRIEVAL PIPELINE</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
          <div className="hidden md:block absolute top-[50px] left-[15%] right-[15%] h-[1px] bg-gradient-to-r from-indigo-500/30 via-cyan-500/30 to-emerald-500/30"></div>
          
          <div className="text-center relative">
            <div className="w-12 h-12 rounded-full bg-indigo-650 text-white font-bold flex items-center justify-center mx-auto mb-6 border border-indigo-500/50 shadow-lg relative z-10">
              01
            </div>
            <h4 className="text-sm font-bold text-white mb-2 font-display">Upload Scientific Payload</h4>
            <p className="text-slate-400 text-xs max-w-xs mx-auto">
              Drag genomic sequences (.fasta), variant charts (.vcf), AST sensitivity csv tables, scientific PDF papers, or structural folders.
            </p>
          </div>

          <div className="text-center relative">
            <div className="w-12 h-12 rounded-full bg-cyan-650 text-white font-bold flex items-center justify-center mx-auto mb-6 border border-cyan-500/50 shadow-lg relative z-10">
              02
            </div>
            <h4 className="text-sm font-bold text-white mb-2 font-display">Targeted AI Decoupling</h4>
            <p className="text-slate-400 text-xs max-w-xs mx-auto">
              Gemini decodes codon mutations and maps resistance factors against updated databases like CARD, ResFinder, and National Institutes of Health markers.
            </p>
          </div>

          <div className="text-center relative">
            <div className="w-12 h-12 rounded-full bg-emerald-650 text-white font-bold flex items-center justify-center mx-auto mb-6 border border-emerald-500/50 shadow-lg relative z-10">
              03
            </div>
            <h4 className="text-sm font-bold text-white mb-2 font-display">Receive Publication Report</h4>
            <p className="text-slate-400 text-xs max-w-xs mx-auto">
              Inspect clinical alerts, ask localized research questions inside the workspace chat frame, and export formatted Markdown reports.
            </p>
          </div>
        </div>

        <div className="text-center mt-16">
          <button
            onClick={onLaunch}
            className="px-10 py-5 bg-gradient-to-r from-indigo-500 to-cyan-500 hover:opacity-95 text-slate-900 font-bold rounded-xl text-xs uppercase tracking-widest inline-flex items-center gap-2 transition-all shadow-xl shadow-cyan-500/10 cursor-pointer"
          >
            Launch Collaborative Platform
            <ChevronRight className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-6 relative z-10 text-slate-500 text-xs font-mono font-medium">
        <div className="flex items-center gap-2">
          <Dna className="w-4 h-4 text-indigo-400" />
          <span>© 2026 AMR Insight AI Platform</span>
        </div>
        <div className="flex items-center gap-6">
          <span>Targeting antimicrobial drug-resistance worldwide</span>
          <span>CARD ontology terms supported</span>
        </div>
      </footer>
    </div>
  );
}
