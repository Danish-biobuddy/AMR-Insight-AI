export enum Tab {
  Landing = "landing",
  Dashboard = "dashboard",
  Upload = "upload",
  Analysis = "analysis",
  Chat = "chat",
  Reports = "reports",
  Library = "library",
  Trends = "trends",
  Settings = "settings"
}

export type FileType = "fasta" | "vcf" | "paper" | "ast" | "genelist" | "protein" | "other";

export interface ResearchFile {
  id: string;
  name: string;
  size: number;
  type: FileType;
  uploadedAt: string;
  status: "processing" | "analyzed" | "error";
  progress: number;
  content: string;
  analysisResult?: string;
  errorMessage?: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  suggestions?: string[];
}

export interface ASTRecord {
  id: string;
  antibiotic: string;
  class: string;
  mic: string;
  sir: "S" | "I" | "R"; // Susceptible, Intermediate, Resistant
}

export interface VariantMutation {
  id: string;
  chromosome: string;
  position: number;
  gene: string;
  refAlt: string;
  codonMutation: string;
  consequence: string;
  relevance: "AMR-Conferring" | "Benign" | "Unknown";
  severityScore: number; // 0 to 100 (Pathogenic score)
  explanation?: string;
}

export interface GeneRecord {
  id: string;
  name: string;
  category: string;
  mechanism: string;
  confidence: "High" | "Medium" | "Low";
}

export interface GeneratedReport {
  id: string;
  title: string;
  type: "full" | "clinical" | "brief";
  createdAt: string;
  content: string;
  filesIncluded: string[];
}

export interface StatCardData {
  title: string;
  value: string | number;
  icon: string;
  change: string;
  trend: "up" | "down" | "neutral";
}
