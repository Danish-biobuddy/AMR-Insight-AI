import React, { useState, useEffect } from "react";
import { 
  Dna, LayoutDashboard, UploadCloud, Activity, MessageSquare, 
  FileText, BookOpen, BarChart3, Settings, Bell, Search, 
  Menu, X, Sun, Moon, LogOut, ChevronRight, Sparkles, ShieldCheck 
} from "lucide-react";
import { Tab, ResearchFile, ChatMessage } from "./types";
import { INITIAL_FILES } from "./initialData";

// Individual Workspace Screen Views
import LandingPage from "./components/LandingPage";
import DashboardView from "./components/DashboardView";
import UploadWorkspace from "./components/UploadWorkspace";
import AnalysisWorkspace from "./components/AnalysisWorkspace";
import ChatWorkspace from "./components/ChatWorkspace";
import ReportWorkspace from "./components/ReportWorkspace";
import LibraryWorkspace from "./components/LibraryWorkspace";
import TrendsWorkspace from "./components/TrendsWorkspace";
import SettingsWorkspace from "./components/SettingsWorkspace";

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>(Tab.Landing);
  const [sidebarExpanded, setSidebarExpanded] = useState(true);
  const [theme, setTheme] = useState<"dark" | "light">("dark");
  
  // Isolate datasets cached in state
  const [files, setFiles] = useState<ResearchFile[]>(INITIAL_FILES);
  const [selectedFile, setSelectedFile] = useState<ResearchFile | null>(INITIAL_FILES[0]);

  // Conversational registers
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: "init-1",
      role: "assistant",
      content: "Hello! I am your AMR AI diagnostic assistant. I am fully grounded with reference ontology criteria. Ask me about specific mutations, gene vectors, or analyze any of your uploaded assemblies on the sidebar.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      suggestions: ["Is blaCTX-M-15 susceptible to Ceftriaxone?"]
    }
  ]);
  const [isChatSending, setIsChatSending] = useState(false);
  const [apiKey, setApiKey] = useState("");

  const handleToggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const handleLaunchWorkspace = () => {
    setActiveTab(Tab.Dashboard);
  };

  const handleAddFile = (newFile: ResearchFile) => {
    // Add to state list
    setFiles(prev => [newFile, ...prev]);
    setSelectedFile(newFile);
  };

  const handleSelectFileFromLibrary = (file: ResearchFile) => {
    setSelectedFile(file);
    setActiveTab(Tab.Analysis);
  };

  const handleDeleteFile = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
    if (selectedFile?.id === id) {
      setSelectedFile(null);
    }
  };

  const handleClearSession = () => {
    setFiles([]);
    setSelectedFile(null);
    setChatMessages([
      {
        id: "init-2",
        role: "assistant",
        content: "Workspace cache purged. Ready to ingest new genomic profiles.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ]);
    setActiveTab(Tab.Upload);
  };

  // Chat message submit dispatcher (proxied server-side)
  const handleSendMessage = async (text: string, activeContextId?: string) => {
    const userMsg: ChatMessage = {
      id: "msg-" + Date.now(),
      role: "user",
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, userMsg]);
    setIsChatSending(true);

    const activeContextFile = files.find(f => f.id === activeContextId);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...chatMessages, userMsg].map(m => ({ role: m.role, content: m.content })),
          activeFileContext: activeContextFile ? {
            name: activeContextFile.name,
            type: activeContextFile.type,
            content: activeContextFile.content,
            metadata: activeContextFile.analysisResult
          } : null
        })
      });

      const data = await response.json();
      if (data.success) {
        const assistantMsg: ChatMessage = {
          id: "msg-ai-" + Date.now(),
          role: "assistant",
          content: data.message,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setChatMessages(prev => [...prev, assistantMsg]);
      } else {
        const errAlertMsg: ChatMessage = {
          id: "msg-ai-err-" + Date.now(),
          role: "assistant",
          content: `⚠️ AI Consultation offline: ${data.error}. If the backend API keys are not specified, please check Settings > Secrets or customize variables.`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setChatMessages(prev => [...prev, errAlertMsg]);
      }
    } catch (err: any) {
      const errFailMsg: ChatMessage = {
        id: "msg-ai-err-conn-" + Date.now(),
        role: "assistant",
        content: `⚠️ Connection failure to proxy: ${err.message || "Failed to reach server-side handler"}.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChatMessages(prev => [...prev, errFailMsg]);
    } finally {
      setIsChatSending(false);
    }
  };

  // If we are on the landing page, show it and bypass sidebar wrappers
  if (activeTab === Tab.Landing) {
    return <LandingPage onLaunch={handleLaunchWorkspace} />;
  }

  return (
    <div className={`min-h-screen font-sans ${theme === "light" ? "bg-slate-50 text-slate-900" : "bg-[#0B0F19] text-slate-100"}`}>
      
      {/* Top Gradient Mesh Blobs (Dark mode exclusive) */}
      {theme === "dark" && (
        <>
          <div id="glow-circle-1" className="absolute top-0 right-1/4 w-[400px] h-[300px] bg-indigo-500/5 rounded-full blur-[100px] pointer-events-none"></div>
          <div id="glow-circle-2" className="absolute top-1/3 left-10 w-[300px] h-[350px] bg-cyan-500/5 rounded-full blur-[100px] pointer-events-none"></div>
        </>
      )}

      {/* Main Full-stack layout wrapper */}
      <div id="fullstack-layout" className="flex">
        
        {/* Sidebar Navigation */}
        <aside 
          id="workspace-sidebar" 
          className={`h-screen sticky top-0 bg-[#0F1320] border-r border-white/5 transition-all duration-300 z-30 flex flex-col justify-between select-none ${
            sidebarExpanded ? "w-60" : "w-18"
          }`}
        >
          {/* Sidebar top header branding */}
          <div className="space-y-6 pt-5">
            <div className={`flex items-center gap-3 px-4 ${sidebarExpanded ? "justify-start" : "justify-center"}`}>
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-indigo-500/10 shrink-0">
                <Dna className="w-5.5 h-5.5 text-slate-950 stroke-[2.5]" />
              </div>
              {sidebarExpanded && (
                <div>
                  <span className="font-display font-medium text-xs tracking-widest text-slate-200 block">AMR INSIGHT</span>
                  <span className="text-[8px] font-mono font-bold text-cyan-400 bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20">AI SURVEILLANCE</span>
                </div>
              )}
            </div>

            {/* Main Tabs Selection list */}
            <nav id="sidebar-tabs" className="px-2 space-y-1">
              {[
                { tab: Tab.Dashboard, label: "Overview", icon: LayoutDashboard },
                { tab: Tab.Upload, label: "Data Ingest", icon: UploadCloud },
                { tab: Tab.Analysis, label: "Bioinformatics Workdesk", icon: Activity },
                { tab: Tab.Chat, label: "Gemini AI Consult", icon: MessageSquare },
                { tab: Tab.Reports, label: "Report Vault", icon: FileText },
                { tab: Tab.Library, label: "Research Library", icon: BookOpen },
                { tab: Tab.Trends, label: "SURVEILLANCE Map", icon: BarChart3 },
                { tab: Tab.Settings, label: "Preferences", icon: Settings },
              ].map((item, idx) => {
                const IconComponent = item.icon;
                const isSelected = activeTab === item.tab;
                return (
                  <button
                    key={idx}
                    onClick={() => setActiveTab(item.tab)}
                    className={`w-full py-2.5 rounded-lg flex items-center gap-3.5 transition-all text-left text-xs font-semibold ${
                      isSelected 
                        ? "bg-indigo-600/15 border-l-2 border-indigo-500 text-indigo-300 px-3.5" 
                        : "text-slate-400 hover:text-white hover:bg-white/[0.02] px-3"
                    }`}
                  >
                    <IconComponent className={`w-4.5 h-4.5 ${isSelected ? "text-indigo-400" : "text-slate-400"}`} />
                    {sidebarExpanded && <span>{item.label}</span>}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Sidebar bottom collapses toggler */}
          <div className="p-4 border-t border-white/5 space-y-3">
            {sidebarExpanded && (
              <div className="p-3 rounded-lg bg-slate-900 border border-white/5 space-y-1.5 text-[10px] font-mono text-slate-500">
                <span className="flex items-center gap-1 text-emerald-400 font-bold">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  SHELL ACTIVE
                </span>
                <span className="block truncate">Researcher: alid62348@gmail.com</span>
              </div>
            )}
            
            <button
              onClick={() => setSidebarExpanded(!sidebarExpanded)}
              className="w-full py-2 rounded bg-slate-900/40 hover:bg-slate-950 border border-slate-800 text-[10px] font-mono text-slate-500 tracking-wider text-center block uppercase"
            >
              {sidebarExpanded ? "Collapse Sidebar" : "Expanded"}
            </button>

            <button
              onClick={() => setActiveTab(Tab.Landing)}
              className="w-full py-1.5 rounded bg-red-500/10 hover:bg-red-500/20 text-red-400 text-[10px] font-mono font-bold tracking-wider text-center flex items-center justify-center gap-1 border border-red-500/15"
              title="Close Workspace"
            >
              <LogOut className="w-3.5 h-3.5" />
              {sidebarExpanded && <span>Close Workspace</span>}
            </button>
          </div>
        </aside>

        {/* Content Side right (including top status bar and active screen wrapper context) */}
        <main id="main-workbench" className="flex-1 min-w-0 flex flex-col h-screen overflow-hidden">
          
          {/* Top workspace bar */}
          <header className="h-16 border-b border-white/5 bg-[#0F1320]/60 backdrop-blur-md px-6 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-4">
              <span className="text-[10px] font-mono font-bold text-slate-500 bg-slate-900 border border-white/5 px-2 py-1 rounded">
                DEPT OF MOLECULAR EPIDEMIOLOGY
              </span>
            </div>

            {/* Topbar shortcuts right */}
            <div className="flex items-center gap-4">
              
              {/* Theme switch button */}
              <button 
                onClick={handleToggleTheme}
                className="p-2 rounded-lg bg-slate-900 border border-white/5 text-slate-400 hover:text-white transition-colors"
                title="Toggle Theme style"
              >
                {theme === "dark" ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-300" />}
              </button>

              {/* Status Alert Notification */}
              <div className="relative">
                <button className="p-2 rounded-lg bg-slate-900 border border-white/5 text-slate-400 hover:text-white transition-colors">
                  <Bell className="w-4 h-4 text-indigo-400" />
                </button>
                <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-red-500"></span>
              </div>

              {/* User Identity profile */}
              <div className="flex items-center gap-2.5 border-l border-white/5 pl-4">
                <div className="w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center font-mono font-black text-xs text-slate-950 font-bold uppercase ring-2 ring-indigo-500/20">
                  AL
                </div>
                <div className="hidden sm:block text-left">
                  <span className="text-xs font-semibold text-slate-300 block">Surveillance Lab</span>
                  <span className="text-[9px] text-slate-500 block font-mono">alid62348</span>
                </div>
              </div>
            </div>
          </header>

          {/* Active module renderer nested in scrollable space */}
          <section id="module-viewport" className="flex-1 p-6 md:p-8 overflow-y-auto max-w-[1400px] mx-auto w-full">
            {activeTab === Tab.Dashboard && (
              <DashboardView 
                files={files} 
                onNavigate={setActiveTab} 
                onSelectFile={handleSelectFileFromLibrary} 
              />
            )}
            
            {activeTab === Tab.Upload && (
              <UploadWorkspace 
                onAddFile={handleAddFile} 
                files={files}
                onNavigateToAnalysis={handleSelectFileFromLibrary}
              />
            )}

            {activeTab === Tab.Analysis && (
              <AnalysisWorkspace 
                files={files}
                selectedFile={selectedFile}
                onSelectFile={setSelectedFile}
                onNavigateToChat={() => setActiveTab(Tab.Chat)}
              />
            )}

            {activeTab === Tab.Chat && (
              <ChatWorkspace 
                files={files}
                chatMessages={chatMessages}
                onSendMessage={handleSendMessage}
                isSending={isChatSending}
              />
            )}

            {activeTab === Tab.Reports && (
              <ReportWorkspace files={files} />
            )}

            {activeTab === Tab.Library && (
              <LibraryWorkspace 
                files={files} 
                onSelectFile={handleSelectFileFromLibrary}
                onDeleteFile={handleDeleteFile}
              />
            )}

            {activeTab === Tab.Trends && (
              <TrendsWorkspace />
            )}

            {activeTab === Tab.Settings && (
              <SettingsWorkspace 
                apiKey={apiKey}
                onUpdateApiKey={setApiKey}
                onClearSession={handleClearSession}
                theme={theme}
                onToggleTheme={handleToggleTheme}
              />
            )}
          </section>

          {/* Dynamic footer status ribbon */}
          <footer className="h-8 border-t border-white/5 bg-[#0F1320] px-6 flex items-center justify-between text-[9px] font-mono text-slate-500 shrink-0 select-none">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              SECURE SECRETS STORAGE ENABLED // NO METADATA DISCLOSURES
            </span>
            <span>CARD TERM MAPPING V2.55 // SYSTEM UP-TO-DATE</span>
          </footer>

        </main>
      </div>

    </div>
  );
}
