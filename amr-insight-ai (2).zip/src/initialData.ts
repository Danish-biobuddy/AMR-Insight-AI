import { ResearchFile, ASTRecord, VariantMutation, GeneRecord } from "./types";

export const INITIAL_FILES: ResearchFile[] = [
  {
    id: "f1",
    name: "E_coli_isolate_blaCTX-M-15_assembly.fasta",
    size: 24048,
    type: "fasta",
    uploadedAt: "2026-06-12 14:32",
    status: "analyzed",
    progress: 100,
    content: `>gi|328530438|gb|JF718241.1| Escherichia coli strain EC12 blaCTX-M-15 gene, complete sequence
ATGGTGACAAAGAGAGTGCAACGGATGATGTTCGCGGCGGCGGTGCTGACTATCGGCGGGCTGGCTTTCGCG
CATCCGATTTTGCAACAGACAGCGGACATTGCAGAGCGTCAGAGTCAGGAGGTCAGAGAGGTGCTGCAGCAG
CCTGCGGTCGCGACGACACCGCAACCGGTGAAAGCGGGCTTCCTTGTGGCTCAGGTTAATGAATATCAGCAG
GTTAATGGCGGGTCGGTGGTTAAGTCGGCGAATCAGCCTGTGGTAGAAGCAGCGAAGGTCGCGACGACACCG
TTAATGAATATCAGAATAATGCGTTCCCGTTCACGGCGTTCGACACCAGTGAAACGGGTTAATGCGTTCACG
GCGGCTCAGGTGGCTCAGGTTAATGAATATCACCAGAATAATGCGTTCCCGTTCACGGCGTTCGACACCAGC
TGGAATGCGTGCTGGGACCAGAATAATGAATATAGGTTAATGAATATCAGCCTGACGGTTTGCAGCCTGTAA`,
    analysisResult: `### Sequence Identification & Features
*   **Species Identification (Homology Match):** *Escherichia coli* ST131 clone.
*   **Gene Found:** **blaCTX-M-15** (Class A extended-spectrum beta-lactamase).
*   **Confidence Score:** **99.8% (High)**
*   **Sequence identity matches:** 100% query coverage to NCBI RefSeq accession \`NG_048943.1\`.

### Resistance Profile & Clinical Relevance
*   **Antibiotic Class Affected:** Cephalosporins (3rd and 4th gens, e.g., Ceftriaxone, Cefotaxime, Cefepime) and Monobactams (Aztreonam).
*   **Resistance Mechanism:** Enzymatic hydrolysis of the beta-lactam ring.
*   **Genetic Context:** Located within a highly mobile insertion element **ISEcp1**, driving high conjugative plasmid transfer rates.

### Suggested Actions& Further Databases
1.  **Susceptibility Alert:** Strongly consider carbapenems or combinations with beta-lactamase inhibitors (e.g., Ceftazidime-Avibactam).
2.  **CARD Verification:** Search ontology term \`ARO:3000632\` in the Comprehensive Antibiotic Resistance Database.
3.  **Plasmid Typing:** Suggest performing plasmid replicion typing (pMLST) to check if hosted on an IncFII replicon.`
  },
  {
    id: "f2",
    name: "K_pneumoniae_suspected_colistin_resistance.vcf",
    size: 4892,
    type: "vcf",
    uploadedAt: "2026-06-13 09:15",
    status: "analyzed",
    progress: 100,
    content: `##fileformat=VCFv4.2
##source=AMRinsightVCFParser
##INFO=<ID=DP,Number=1,Type=Integer,Description="Total Depth">
#CHROM	POS	ID	REF	ALT	QUAL	FILTER	INFO
Chr1	471920	.	C	T	999	PASS	DP=45;GENE=mgrB;CONSEQUENCE=missense
Chr1	1028301	.	G	A	999	PASS	DP=62;GENE=gyrA;CONSEQUENCE=missense
Chr1	1240982	.	A	G	999	PASS	DP=38;GENE=parC;CONSEQUENCE=synonymous
Chr1	2304910	.	T	C	999	PASS	DP=50;GENE=pmrB;CONSEQUENCE=missense`,
    analysisResult: `### VCF Mutation Profiling Summary
A total of **4 genomic variants** were loaded. **3 nonsynonymous mutations** have been identified in core AMR-associated determinants.

### High-Impact Mutations Highlighted:
1.  **Gene:** \`mgrB\` (Chr1:471920, **C → T**)
    *   **Codon Change:** \`Gln30Stop\` (Nonsense mutation)
    *   **Severity Score:** **98/100 (Critical)**
    *   **AMR Relevance:** **Pathogenic / AMR-Conferring**. Loss-of-function in \`mgrB\` leads to upregulation of the PhoP/PhoQ two-component system, triggering lipopolysaccharide (LPS) modification. This mediates a **High-Level resistance to Colistin**.
2.  **Gene:** \`gyrA\` (Chr1:1028301, **G → A**)
    *   **Codon Change:** \`Ser83Phe\`
    *   **Severity Score:** **88/100 (High)**
    *   **AMR Relevance:** **Pathogenic / AMR-Conferring**. Disrupts hydro-phobic contacts in the Quinolone Resistance-Determining Region (QRDR), yielding intermediate-to-high level **Fluoroquinolone Resistance (Ciprofloxacin, Levofloxacin)**.
3.  **Gene:** \`pmrB\` (Chr1:2304910, **T → C**)
    *   **Codon Change:** \`Thr156Ala\`
    *   **Severity Score:** **45/100 (Moderate)**
    *   **AMR Relevance:** **Unknown Significance/Flagged**. Mutation is in the linker region. Requires phenotypic susceptibility correlation to verify if it increases Colistin MICs.`
  },
  {
    id: "f3",
    name: "AST_Pan_Drug_A_baumannii_ICU_Report.ast",
    size: 1024,
    type: "ast",
    uploadedAt: "2026-06-15 10:11",
    status: "analyzed",
    progress: 100,
    content: `IPM:R,MER:R,CIP:R,GEN:R,TOB:R,AMK:R,CST:S,TGC:I,SXT:R,FEP:R`,
    analysisResult: `### AST Report Susceptibility Interpretation
*   **Pathogen Profile:** *Acinetobacter baumannii* (ICU respiratory isolate).
*   **Classification:** **MDR (Multidrug-Resistant)** matching criteria for Carbapenem-Resistant *A. baumannii* (CRAB).

### Susceptibility Layout Table
*   **Resistant (R):** Imipenem, Meropenem, Ciprofloxacin, Gentamicin, Tobramycin, Amikacin, Cefepime, Trimethoprim-Sulfamethoxazole.
*   **Intermediate (I):** Tigecycline (MIC = 4 mg/L).
*   **Susceptible (S):** Colistin (MIC <= 1 mg/L).

### Phenotype Assessment
The profile suggests expression of Class D Carbapenemases (such as **OXA-23** or **OXA-51** up-regulated by insertion sequence \`ISAba1\`), alongside aminoglycoside modifying enzymes (AMEs). Colistin remains the last salvage monotherapy options.`
  },
  {
    id: "f4",
    name: "Carbapenemase_Plasmid_Dynamics_Oxford_Review.pdf",
    size: 15480,
    type: "paper",
    uploadedAt: "2026-06-11 11:00",
    status: "analyzed",
    progress: 100,
    content: `Abstract: Here we analyze the transfer kinetics of plasmid-mediated KPC-3 and NDM-1 carbapenemases among Enterobacteriaceae. We isolated a hyperconjugative IncX3 plasmid carrying NDM-5...`,
    analysisResult: `### PDF Literature Summary: *Carbapenemase Plasmid Dynamics Review*

### 1. Abstract Summary:
The study presents the kinetics of plasmid conjugation driving the rapid dissemination of carbapenemases (\`blaKPC-3\` and \`blaNDM-1\`) among Enterobacteriaceae. It highlights a hyperconjugative **IncX3** plasmid hosting \`blaNDM-5\` that transfers in water reservoirs at high rates.

### 2. Relevant AMR Genes Found:
*   \`blaNDM-1\` and \`blaNDM-5\` (New Delhi metallo-beta-lactamase)
*   \`blaKPC-3\` (*Klebsiella pneumoniae* Carbapenemase)

### 3. Key Findings:
- IncX3 plasmids show no detectable fitness cost on host *E. coli* or *K. pneumoniae*.
- Conjugative transfer occurred even at lower ambient temperatures (18°C), indicating potential environmental persistence on wastewater surfaces.`
  },
  {
    id: "f5",
    name: "MRSA_vancomycin_intermediate_gene_list.csv",
    size: 2048,
    type: "genelist",
    uploadedAt: "2026-06-10 08:30",
    status: "analyzed",
    progress: 100,
    content: `vraS,vraR,graS,graR,walK,walR`,
    analysisResult: `### Gene List Analysis: *VISA/MRSA cell-wall thickness mutants*
The uploaded query lists genes belonging to the principal **two-component regulators** that govern cell wall synthesis and thickness in *Staphylococcus aureus*, associated with **VISA (Vancomycin-Intermediate S. aureus)** phenotypes.

### Individual Gene Explanations:
1.  **vraS / vraR:**
    *   **Mechanism:** Cell wall peptidoglycan synthesis sensor/regulator. When mutated or overactive, it upregulates \`pbp2\` and \`sgtB\`, thickening the peptidoglycan matrix and trapping Vancomycin Molecules.
    *   **AMR Antibiotic:** Glycopeptides (Vancomycin, Teicoplanin).
    *   **Confidence:** **High** (CARD ontology linked).
2.  **graS / graR:**
    *   **Mechanism:** Regulates cell-envelope charge. Mutants increase shell D-alanylation, creating positive charges that repel cationic daptomycin/vancomycin.
    *   **AMR Antibiotic:** Glycopeptides and Lipopeptides (Daptomycin).
3.  **walK / walR (yvcG / yvcF):**
    *   **Mechanism:** Master regulator of cell wall autolysis. Downregulation prevents autolytic enzymes from opening the wall under vancomycin stress.`
  },
  {
    id: "f6",
    name: "TEM-1_beta_lactamase_pocket.png",
    size: 145000,
    type: "protein",
    uploadedAt: "2026-06-15 08:44",
    status: "analyzed",
    progress: 100,
    content: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==",
    analysisResult: `### Molecular Protein Structure Analysis
*   **Protein Target:** Class A beta-lactamase **TEM-1**.
*   **Visual Domain Observation:** Deep catalytic groove housing the catalytic Ser70 nucleophile.

### Mutational Hotspots identified in structures:
*   **Glu104Lys / Gly238Ser:** These substitutions in the Omega loop region expand the binding pocket. This accommodates larger cephalosporin sidechains, effectively transitioning TEM-1 into an **extended-spectrum beta-lactamase (ESBL)** (yielding TEM-3, TEM-10, TEM-26 variants).
*   **Met69Leu / Met69Val:** Yields steric restriction in the inhibitor-binding zone, causing **Inhibitor-Resistant TEM (IRT)** phenotypes that escape Clavulanic Acid or Sulbactam.`
  }
];

export const MOCK_AST_TABLE: ASTRecord[] = [
  { id: "ast-1", antibiotic: "Imipenem", class: "Carbapenems", mic: ">= 16 mg/L", sir: "R" },
  { id: "ast-2", antibiotic: "Meropenem", class: "Carbapenems", mic: ">= 16 mg/L", sir: "R" },
  { id: "ast-3", antibiotic: "Ertapenem", class: "Carbapenems", mic: "8 mg/L", sir: "R" },
  { id: "ast-4", antibiotic: "Ceftriaxone", class: "Cephalosporins", mic: "64 mg/L", sir: "R" },
  { id: "ast-5", antibiotic: "Cefepime", class: "Cephalosporins", mic: "32 mg/L", sir: "R" },
  { id: "ast-6", antibiotic: "Ciprofloxacin", class: "Fluoroquinolones", mic: "4 mg/L", sir: "R" },
  { id: "ast-7", antibiotic: "Levofloxacin", class: "Fluoroquinolones", mic: "2 mg/L", sir: "I" },
  { id: "ast-8", antibiotic: "Gentamicin", class: "Aminoglycosides", mic: ">= 16 mg/L", sir: "R" },
  { id: "ast-9", antibiotic: "Amikacin", class: "Aminoglycosides", mic: "4 mg/L", sir: "S" },
  { id: "ast-10", antibiotic: "Colistin", class: "Polymyxins", mic: "<= 0.5 mg/L", sir: "S" },
  { id: "ast-11", antibiotic: "Tigecycline", class: "Tetracyclines", mic: "2 mg/L", sir: "I" },
  { id: "ast-12", antibiotic: "Piperacillin/Tazo", class: "Beta-lactamase combinations", mic: "128 mg/L", sir: "R" }
];

export const MOCK_VCF_RECORDS: VariantMutation[] = [
  {
    id: "vcf-1",
    chromosome: "Chr_1",
    position: 471920,
    gene: "mgrB",
    refAlt: "C -> T",
    codonMutation: "Gln30Stop",
    consequence: "Nonsense (truncation)",
    relevance: "AMR-Conferring",
    severityScore: 98,
    explanation: "Loss-of-function in mgrB inactivates feedback regulation on PhoQ, changing membrane charge and reducing colistin affinity. Confirmed in CARD database."
  },
  {
    id: "vcf-2",
    chromosome: "Chr_1",
    position: 1028301,
    gene: "gyrA",
    refAlt: "G -> A",
    codonMutation: "Ser83Phe",
    consequence: "Missense substitution",
    relevance: "AMR-Conferring",
    severityScore: 88,
    explanation: "Standard QRDR mutation that dramatically reduces Ciprofloxacin binding to the DNA gyrase complex."
  },
  {
    id: "vcf-3",
    chromosome: "Chr_1",
    position: 1104443,
    gene: "parC",
    refAlt: "T -> G",
    codonMutation: "Ser80Ile",
    consequence: "Missense substitution",
    relevance: "AMR-Conferring",
    severityScore: 84,
    explanation: "Secondary target substitution in topoisomerase IV that acts synergistically with gyrA Ser83 mutations."
  },
  {
    id: "vcf-4",
    chromosome: "Chr_1",
    position: 2304910,
    gene: "pmrB",
    refAlt: "T -> C",
    codonMutation: "Thr156Ala",
    consequence: "Missense substitution",
    relevance: "Unknown",
    severityScore: 45,
    explanation: "Noted in some clinical isolates, but physical studies lack high-confidence evidence linking this single variant to clinical colistin escape."
  },
  {
    id: "vcf-5",
    chromosome: "Chr_2",
    position: 301050,
    gene: "pbp3",
    refAlt: "A -> G",
    codonMutation: "Ala12Val",
    consequence: "Missense substitution",
    relevance: "Benign",
    severityScore: 12,
    explanation: "Highly polymorphic surface loop. Showcases no effect on the beta-lactam binding pocket conformation or susceptibility thresholds."
  }
];

export const MOCK_GENES: GeneRecord[] = [
  { id: "g1", name: "blaKPC-3", category: "Beta-lactamase", mechanism: "Enzymatic carbapenem hydrolysis", confidence: "High" },
  { id: "g2", name: "mcr-1.5", category: "LPS Modifying Transferase", mechanism: "Phosphoethanolamine modification of Lipid A", confidence: "High" },
  { id: "g3", name: "tet(X4)", category: "Enzymatic Destabilizer", mechanism: "Flavin-dependent tetracycline monooxygenase", confidence: "High" },
  { id: "g4", name: "aac(6')-Ib-cr", category: "Aminoglycoside/Fluoroquinolone Modifier", mechanism: "Aminoglycoside acetyltransferase", confidence: "High" },
  { id: "g5", name: "armA", category: "Ribosomal Methyltransferase", mechanism: "16S rRNA methylation (high aminoglycoside resistance)", confidence: "High" },
  { id: "g6", name: "oqxAB", category: "Efflux Pump", mechanism: "RND-family multidrug active efflux", confidence: "Medium" }
];

export const TRENDS_TIME_SERIES = [
  { year: "2020", MRSA: 31, CarbapenemResistantKleb: 22, ColistinResistant: 1.8 },
  { year: "2021", MRSA: 29, CarbapenemResistantKleb: 26, ColistinResistant: 2.1 },
  { year: "2022", MRSA: 28, CarbapenemResistantKleb: 31, ColistinResistant: 3.5 },
  { year: "2023", MRSA: 25, CarbapenemResistantKleb: 34, ColistinResistant: 4.8 },
  { year: "2024", MRSA: 24, CarbapenemResistantKleb: 39, ColistinResistant: 6.2 },
  { year: "2025", MRSA: 22, CarbapenemResistantKleb: 43, ColistinResistant: 8.5 },
  { year: "2026", MRSA: 20, CarbapenemResistantKleb: 48, ColistinResistant: 10.2 }
];

export const GENE_FREQUENCY_DISTRIBUTION = [
  { name: "blaCTX-M", frequency: 45 },
  { name: "blaOXA", frequency: 32 },
  { name: "blaTEM", frequency: 28 },
  { name: "blaNDM", frequency: 18 },
  { name: "blaKPC", frequency: 12 },
  { name: "mgrB mutants", frequency: 8 },
  { name: "mcr-1", frequency: 5 },
  { name: "tet(X4)", frequency: 3 }
];
